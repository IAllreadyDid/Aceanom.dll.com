#ifndef __SAUCE_H__
#define __SAUCE_H__

typedef struct {
	char id[5];
	char version[2];
	char title[35];
	char author[20];
	char group[20];
	char date[8];
	signed long filesize;
	unsigned char datatype;
	unsigned char filetype;
	unsigned short tinfo1;
	unsigned short tinfo2;
	unsigned short tinfo3;
	unsigned short tinfo4;
	unsigned char comments;
	unsigned char flags;
	char filler[22];
} SAUCE;

#endif
