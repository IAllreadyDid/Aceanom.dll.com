#include <ncurses.h>
#include <editor.h>
#include <multidraw.h>

#ifndef __FUNC_H_
#define __FUNC_H_

/* multidraw.c */

int md_getch();
int md_sendcmd(int, char *);
void remote_create();
void remote_destroy();
int remote_connect(char *, int );
int remote_connect_server(int );
void remote_disconnect();

/* save.c */
void savefile(page *);
int save_c(page *, const char *);
int save_ansi(page *, const char *);

/* load.c */
page *load_ansi(const char *);
page *loadfile(page *);

/* interface.c */
void multidraw_screen(page *);
WINDOW *drawstart_logo();
WINDOW *drawexit_logo();
void tet_options();
void drawstatus(page *, int);
void drawcolours(page *);
void drawcolours_stat(page *,WINDOW *cwin);
char *fchooser();
void help_screen();

/* editor.c */
void move_down(page *, int );
void move_up(page *, int );
void move_left(page *, int );
void move_right(page *, int );

void line_add(page *, int );
void line_insert(page *, int );
void line_delete(page *, int );

void char_insert(page *, chtype );
void char_add(page *, chtype );
void char_add_l(page *, chtype );
void char_del(page *, int);

page *page_factory(page *, int );
void update(page *);

void draw_block(page *, int, int, int, int);
void block_command(page *);
void show_region(page *, page *);
page *copy_region(page *, int , int , int , int);
page *move_region(page *, int , int , int , int);

void draw_line(page *, int, int, int, int);

void select_f_fg(int *);
void select_f_bg(int *);
void select_f_char(int *);
void select_r_fg(int *, int *);
void select_r_bg(int *, int *);
void select_r_char(int *, int *);

chtype attrib(page *,chtype );
chtype remote_attrib(chtype);

/* main.c */

void save_config();

#endif
