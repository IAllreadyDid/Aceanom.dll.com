#include <ncurses.h>

#ifndef __EDITOR_H
#define __EDITOR_H

#define PAGE_RESURRECT 0
#define PAGE_DECOMPOSE 1

typedef struct {
	chtype **buff;
	int x;
	int y;
	int oy;
	int ly;
	int fg;
	int bg;
	int bold;
	int flash;
	int hy;
	int insert;
	int hascii;
	int above;
	int below;
	int statusbar;
	WINDOW *EditWin;
} page; 

typedef struct {
	char flip_x[100][2];
	char flip_y[100][2];
	char sauce_author[21];
	char sauce_group[21];
	char sauce_title[36];
	char save_default[7];
	int highascii[21][10];
	int flip_fix;
	char save_sauce[6];
	int default_charset;
	int auto_save;
	int auto_time;
	int show_logo;
	int logo_timeout;
	int sb_top;
} options;

#endif
