/*
 *
 * multidraw.c by ttb(John McCutchan)
 *
 * tetradraw multidraw support
 *
 */

#include <errno.h>
#include <sys/time.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

#include <editor.h>
#include <multidraw.h>
#include <global.h>
#include <func.h>

int md_getch();
int md_sendcmd( int, char *);
int md_handlemsg(char *);
int remote_connect(char *, int);
int remote_connect_server(int);
void remote_disconnect();
void remote_create(page *);
void remote_destroy();
void add_cmsg(char *);

void add_cmsg(char *msg) {
	int count = 0;
	if (remote->ccount+1<8) {
		remote->chat[remote->ccount] = strdup(msg);
		remote->ccount++;
		return;
	}
	free(remote->chat[0]);
	for(count = 0; count < 7; count++) {
		remote->chat[count] = remote->chat[count+1];
	}
	remote->chat[7] = strdup(msg);
}

int md_getch() {
	char msg[2048];
	fd_set rdfs;
	struct timeval tv;
	static int count = 0;
	int ch = -1;
	int blah;
	int rb;

	FD_ZERO(&rdfs);
	FD_SET(0, &rdfs);
	if (remote && remote->sock > 0) {
		FD_SET(remote->sock, &rdfs);
	}
	tv.tv_sec = 5;
	tv.tv_usec = 0;
	if (remote && remote->sock > 0) {
		blah = select(remote->sock+1, &rdfs, NULL, NULL, NULL);
	} else {
		blah = select(1, &rdfs, NULL, NULL, NULL);
	}
	if (blah>0) {
		if (remote && remote->sock > 0) {
			if (FD_ISSET(remote->sock, &rdfs)) {	
				while (count < 1024) {
					rb = recv(remote->sock, (char *)(msg + count), 1, 0);
					if (rb == 0) {
						close(remote->sock);
						remote_destroy();
						msg[0] = '\0';
						return -1;
					} else if (rb < 0) {
						remote_destroy();
						return -1;
					}
					if (msg[count]=='\0') {
						md_handlemsg(msg);
						count = 0;
						msg[count] = '\0';
						return ch;
					}
					count++;
				}
			}
		}	
		if (FD_ISSET(0, &rdfs)) {
			ch = getch();
		} 
	} else if (blah < 0) {  
		return -1;
	}
	return ch;
}

int md_sendcmd(int cmdcode, char *cmdargs) {
	char msg[2048];
	int count = 0;
	int len = strlen(cmdargs);

	msg[0] = cmdcode & 0xFF;

	while(count <= len && count < 1024) {
		msg[1+count] = cmdargs[count];
		count++;
	}
	msg[1+count] = '\0';
	if (msg[0] == CMD_TALK) 
		add_cmsg(msg+1);
	return send(remote->sock, msg, 1+count, 0);
}

int md_handlemsg(char *msg) {
	int count; /* for command repeat counting */
	int y, countx; /* for CINSERT, CDEL */

	switch (msg[0]) {
		case CMD_HELO:
			remote->remotehandle = strdup((char *)(msg+1));
			break;
		case CMD_TALK:
			add_cmsg(msg+1);
			break;
		case CMD_DOWN:
			for(count = 0; count < msg[1]; count++) {
				if (remote->y+1 >= 23) {
					if (!((remote->oy + remote->y + 1) < remote->wrkpage->ly))
						line_add(remote->wrkpage, 1);
					remote->oy++;
				} else {
					if (!((remote->oy + remote->y + 1) < remote->wrkpage->ly))
						line_add(remote->wrkpage, 1);
					remote->y++;
				}
			}
			break;
		case CMD_UP:
			for(count = 0; count < msg[1]; count++) {
				if (remote->y-1 < 0) {
					if (remote->oy -1 >= 0) 
						remote->oy--;
				} else remote->y--;
			}
			break;
		case CMD_LEFT:
			for(count = 0; count < msg[1]; count++) 
				if (remote->x - 1 >= 0) remote->x--; else break;
			break;
		case CMD_RIGHT:
			for(count = 0; count < msg[1]; count++)
				if (remote->x + 1 < 80) remote->x++; else break;
			break;
		case CMD_COLOUR:
			remote->fg = atoi((char *)msg+1);
			while(*msg != ',') msg++;
			remote->bg = atoi(msg+1);
			break;
		case CMD_FLASH:
			remote->flash = msg[1] - '0';
			break;
		case CMD_BOLD:
			remote->bold = msg[1] - '0';
			break;
		case CMD_POS:
			remote->x = atoi(msg+1);
			while(*msg != ',') msg++;
			remote->oy = atoi(msg+1);
			while(*msg != ',') msg++;
			remote->y = atoi(msg+1);
			break;
		case CMD_INSERT:
			remote->insert = (int)msg[1] - '0';
			break;
		case CMD_CINSERT:
			countx = 78;
			y = remote->y + remote->oy;
			for(; countx >= remote->x; countx--) 
				remote->wrkpage->buff[y][countx + 1] = remote->wrkpage->buff[y][countx];
			remote->wrkpage->buff[y][remote->x] = (msg[1] & 0xFF) | remote_attrib((msg[1] & 0xFF));
			break;
		case CMD_CDEL:
			for(count = 0; count < msg[1]; count++) {
				countx = remote->x;
				y = remote->y + remote->oy;
				remote->wrkpage->buff[y][79] = ' ' | A_NORMAL;
				for(; countx < 79; countx++) 
					remote->wrkpage->buff[y][countx] = remote->wrkpage->buff[y][countx + 1];
			}
			break;
		case CMD_CADD:
			remote->wrkpage->buff[remote->y + remote->oy][remote->x] = (msg[1] & 0xFF) |  remote_attrib((msg[1] & 0xFF));
			break;
	}
	return 0;
}

int remote_connect(char *hostname, int port) {
	int sock = 0;
	struct hostent *lookup = (struct hostent *)NULL;
	struct sockaddr_in dest_addr;

	if ((lookup = gethostbyname(hostname)) == NULL) {
		return -3;
	}

	if ((sock = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
		return -2;
	}

	dest_addr.sin_family = AF_INET;
	dest_addr.sin_port = htons(port);
	memcpy(&dest_addr.sin_addr, lookup->h_addr, lookup->h_length);
	memset(dest_addr.sin_zero, 0, 8);

	if (connect(sock, (struct sockaddr *)&dest_addr, sizeof(struct sockaddr)) == -1) {
		return -1;
	}
	return sock;
}

void remote_disconnect() {
	if (remote->sock != 0) 
		close(remote->sock);
	remote->sock = 0;
}

void remote_create(page *buff) {
	int count = 0;
	multid *goal = (multid *)NULL;

	goal = (multid *)malloc(sizeof(multid));

	goal->wrkpage = buff;
	goal->sock = 0;
	goal->x = 0;
	goal->y = 0;
	goal->oy = 0;
	goal->fg = 7;
	goal->bg = 0;
	goal->bold = 0;
	goal->flash = 0;
	goal->localhandle = (char *)NULL;
	goal->remotehandle = (char *)NULL;
	goal->ccount = 0;
	for(count = 0; count < 8; count++) 
		goal->chat[count] = (char *)NULL;
	remote = goal;
}

void remote_destroy() {
	if (remote->remotehandle != NULL)
		free(remote->remotehandle);
	if (remote->localhandle != NULL)
		free(remote->localhandle);
	if (remote!=NULL)
		free(remote);
	remote = NULL;
}

int remote_connect_server(int port) {
	int sock = 0;
	int fsock = 0;
	struct sockaddr_in my_addr;
	struct sockaddr_in r_addr;
	int sin_size;

	sock = socket(AF_INET, SOCK_STREAM, 0);

	my_addr.sin_family = AF_INET;
	my_addr.sin_port = htons(port);
	my_addr.sin_addr.s_addr = htonl(INADDR_ANY);
	memset(&(my_addr.sin_zero), 0, 8);

	if (bind(sock, (struct sockaddr *)&my_addr, sizeof(struct sockaddr)) == -1) {
		return -3;
	}

	if (listen(sock, 1) == -1) {
		return -2;
	}

	sin_size = sizeof(struct sockaddr_in);
	fsock = accept(sock, &r_addr, &sin_size);
	close(sock);
	return fsock;
}
