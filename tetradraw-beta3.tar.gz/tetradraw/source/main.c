/*
 * main.c by ttb (John McCutchan)
 *
 * tetradraw main(int argc, char **argv);
 */


#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <ctype.h>
#include <time.h>

#include <ncurses.h>
#include <keydefs.h>
#include <stdlib.h>
#include <func.h>
#include <editor.h>
#include <multidraw.h>

options tet_opts;
int cpage, tpage;
int server;
int colours[8][8];
multid *remote;
page *pages[10];

void read_config();

int main(int argc, char **argv) {
	int count = 0, c = 0;
	time_t ls_t;
	time_t curtime;
	struct tm *timepntr = (struct tm *)NULL;
	WINDOW *Logo = (WINDOW *)NULL;
	int remotey = 0;
	char *m = (char *)NULL;

	ls_t = curtime = time(NULL);

	cpage = 0;
	tpage = 0;
	initscr();
	cbreak();
	noecho();
	nonl();
	keypad(stdscr, TRUE);

	if(has_colors()) {
		start_color();
		for(count = 1;count < COLOR_PAIRS;count++) {
			init_pair(count, count % COLORS, count / COLORS);
			colours[count % COLORS][count / COLORS] = count;
		}
		init_pair(64, COLOR_BLACK, COLOR_BLACK);
		colours[COLOR_BLACK][COLOR_BLACK] = 64;
	}

	define_key("\e1", KEY_ALT_1);
	define_key("\e2", KEY_ALT_2);
	define_key("\e3", KEY_ALT_3);
	define_key("\e4", KEY_ALT_4);
	define_key("\e5", KEY_ALT_5);
	define_key("\e6", KEY_ALT_6);
	define_key("\e7", KEY_ALT_7);
	define_key("\e8", KEY_ALT_8);
	define_key("\e9", KEY_ALT_9);
    define_key("\e0", KEY_ALT_10);
	define_key("\e!", KEY_ALT_11);
	define_key("\e@", KEY_ALT_12);
	define_key("\e#", KEY_ALT_13);
	define_key("\e$", KEY_ALT_14);
	define_key("\e%", KEY_ALT_15);
	define_key("\e^", KEY_ALT_16);
	define_key("\e&", KEY_ALT_17);
	define_key("\e*", KEY_ALT_18);
	define_key("\e(", KEY_ALT_19);
	define_key("\e)", KEY_ALT_20);
	define_key("\eq", KEY_QUIT);
	define_key("\eQ", KEY_QUIT);
	define_key("\es", KEY_ASAVE);
	define_key("\eS", KEY_ASAVE);
	define_key("\el", KEY_LOAD);
	define_key("\eL", KEY_LOAD);
	define_key("\e\e", KEY_COLOUR);
	define_key("\eb", KEY_BLOCK);
	define_key("\eB", KEY_BLOCK);
	define_key("\e.", KEY_NEXT_PAGE);
	define_key("\e,", KEY_PREV_PAGE);
	define_key("\en", KEY_NEW_PAGE);
	define_key("\eN", KEY_NEW_PAGE);
	define_key("\ek", KEY_KILL_PAGE);
	define_key("\eK", KEY_KILL_PAGE);
	define_key("\et", KEY_SWITCH_SB);
	define_key("\eT", KEY_SWITCH_SB);
	define_key("\eh", KEY_HELP);
	define_key("\eH", KEY_HELP);
	define_key("\eo", KEY_OPTIONS);
	define_key("\eO", KEY_OPTIONS);
	define_key("\em", KEY_MULTIDRAW);
	define_key("\eM", KEY_MULTIDRAW);
	define_key("\ef", KEY_FLASH);
	define_key("\eF", KEY_FLASH);


	read_config();

	if (tet_opts.show_logo) {
		Logo = drawstart_logo();
		refresh();
		wrefresh(Logo);
	}

	if (tet_opts.show_logo) {
		if (!tet_opts.logo_timeout)
			md_getch();
		else sleep(tet_opts.logo_timeout);
		delwin(Logo);
	}
	pages[cpage] = page_factory(pages[cpage], PAGE_RESURRECT);
	remote = NULL;

	drawstatus(pages[cpage], cpage);

	if (pages[cpage]->statusbar == 0) 
		wmove(stdscr, pages[cpage]->y+1, pages[cpage]->x);
	else
		wmove(stdscr, pages[cpage]->y, pages[cpage]->x);

	wrefresh(pages[cpage]->EditWin);
	refresh();
	while((c = md_getch())) {
		wrefresh(pages[cpage]->EditWin);
		switch (c) {
			case -1: break;
			case KEY_UP: 
				move_up(pages[cpage], 1);
				break;
			case 13:
				move_down(pages[cpage], 1);
				break;
			case KEY_DOWN:
				move_down(pages[cpage], 1);
				break;
			case KEY_LEFT:
				move_left(pages[cpage], 1);
				break;
			case KEY_RIGHT:
				move_right(pages[cpage], 1);
				break;
			case KEY_BACKSPACE:
				char_del(pages[cpage], 1);
				move_left(pages[cpage], 1);
				break;
			case KEY_DEL:
				char_del(pages[cpage], 1);
				break;
			case KEY_INSERT:
				if (pages[cpage]->insert) {
					pages[cpage]->insert = 0; 
					if (remote && remote->wrkpage == pages[cpage]) {
						m = (char *)malloc(1024);
						sprintf(m, "%d", 0);
						md_sendcmd(CMD_INSERT, m);
						free(m);
						m = (char *)NULL;
					}
				} else {
					pages[cpage]->insert = 1;
					if (remote && remote->wrkpage == pages[cpage]) {
						m = (char *)malloc(1024);
						sprintf(m, "%d", 1);
						md_sendcmd(CMD_INSERT, m);
						free(m);
						m = (char *)NULL;
					}
				}
				break;
			case KEY_FLASH:
				if (pages[cpage]->flash) {
					pages[cpage]->flash = 0; 
					if (remote && remote->wrkpage == pages[cpage]) {
						m = (char *)malloc(1024);
						sprintf(m, "%d", 0);
						md_sendcmd(CMD_FLASH, m);
						free(m);
						m = (char *)NULL;
					}
				} else { 
					pages[cpage]->flash = 1;
					if (remote && remote->wrkpage == pages[cpage]) {
						m = (char *)malloc(1024);
						sprintf(m, "%d", 1);
						md_sendcmd(CMD_FLASH, m);
						free(m);
						m = (char *)NULL;
					}
				}
				break;
			case KEY_HOME:
				pages[cpage]->x = 0;
				if (remote && remote->wrkpage == pages[cpage]) {
					m = (char *)malloc(1024);
					sprintf(m, "%d,%d,%d", 0, remote->wrkpage->oy, remote->wrkpage->y);
					md_sendcmd(CMD_POS, m);
					free(m);
					m = (char *)NULL;
				}
				break;
			case KEY_END:
				pages[cpage]->x = 79;
				if (remote && remote->wrkpage == pages[cpage]) {
					m = (char *)malloc(1024);
					sprintf(m, "%d,%d,%d", 79, remote->wrkpage->oy, remote->wrkpage->y);
					md_sendcmd(CMD_POS, m);
					free(m);
					m = (char *)NULL;
				}
				break;
			case KEY_PAGEUP:
				if (pages[cpage]->y == 23) {
						move_up(pages[cpage], 23);
						move_up(pages[cpage], 23);
				} else move_up(pages[cpage], 23);
				break;
			case KEY_PAGEDOWN:
				if (pages[cpage]->y == 0) {
						move_down(pages[cpage], 23);
						move_down(pages[cpage], 23);
				} else move_down(pages[cpage], 23);
				break;
			case KEY_OPTIONS:
				tet_options();
				break;
			case KEY_ASAVE:
				savefile(pages[cpage]);
				break;
			case KEY_LOAD:
				pages[cpage] = loadfile(pages[cpage]);
				break;
			case KEY_COLOUR:
				drawcolours(pages[cpage]);
				if (remote && pages[cpage] == remote->wrkpage) {
					m = (char *)malloc(1024);
					sprintf(m, "%d,%d", remote->wrkpage->fg, remote->wrkpage->bg);
					md_sendcmd(CMD_COLOUR, m);
					sprintf(m, "%d", remote->wrkpage->bold);
					md_sendcmd(CMD_BOLD, m);
					free(m);
					m = (char *)NULL;
				}
				break;
			case KEY_NEXT_PAGE:
				if (cpage+1<=tpage) cpage++;
				break;
			case KEY_PREV_PAGE:
				if (cpage-1>=0) cpage--;
				break;
			case KEY_NEW_PAGE:
				if (tpage+1<10) { 
					tpage++;
					cpage = tpage;
					pages[cpage] = page_factory(pages[cpage], PAGE_RESURRECT);
				}
				break;
			case KEY_KILL_PAGE:
				if (tpage-1>=0) {
					page_factory(pages[tpage], PAGE_DECOMPOSE);
					tpage--;
					cpage = tpage;
				}
				break;
			case KEY_MULTIDRAW:
				multidraw_screen(pages[cpage]);
				break;
			case KEY_SWITCH_SB:
				if (pages[cpage]->statusbar == 0) {
					pages[cpage]->statusbar = 24;
					mvwin(pages[cpage]->EditWin, 0, 0);
				} else {
					pages[cpage]->statusbar = 0;
					mvwin(pages[cpage]->EditWin, 1, 0);
				}
				break;
			case KEY_HELP:
				help_screen();
				break;
			case KEY_BLOCK:
				block_command(pages[cpage]);
				break;
			case KEY_QUIT:
				goto shutdown;
			default:
				if ( (c>=KEY_ALT_1) && (c<=KEY_ALT_20)) 
					pages[cpage]->hascii = c - 701;
				if (c >= 32 && c < 128) {
					(pages[cpage]->insert) ? char_insert(pages[cpage], c) : char_add(pages[cpage], c); update(pages[cpage]); }
				else if ((c>=265)&&(c<=274)) { (pages[cpage]->insert) ? char_insert(pages[cpage], tet_opts.highascii[pages[cpage]->hascii][c - 265]) : char_add(pages[cpage], tet_opts.highascii[pages[cpage]->hascii][c - 265]); update(pages[cpage]); 
				c = tet_opts.highascii[pages[cpage]->hascii][c - 265];}
				break;
		}
		if (tet_opts.auto_save&&tet_opts.auto_time>0) {
			if ((time(NULL)-ls_t)>(tet_opts.auto_time*60)) {
				char *homedir = (char *)NULL;
				char *filename = (char *)NULL;
				ls_t = time(NULL);
				timepntr = localtime(&ls_t);
				homedir = getenv("HOME");
				filename = (char *)malloc(strlen(homedir) + strlen("/.tetrdraw-autosave.ans") + 1);
				sprintf(filename, "%s%s", homedir, "/.tetradraw-autosave.ans");
				save_ansi(pages[cpage], filename);
				free(homedir);
				free(filename);
			}
		}
		drawstatus(pages[cpage], cpage);
		if (pages[cpage]->statusbar == 0) {
				wmove(stdscr, pages[cpage]->y+1, pages[cpage]->x);
		} else {
				wmove(stdscr, pages[cpage]->y, pages[cpage]->x);
		}
		update(pages[cpage]);
		if (remote) {
			remotey = remote->oy + remote->y;
			if (remotey <= remote->wrkpage->oy + 24
					&& remotey >= remote->wrkpage->oy) {
			mvwaddch(remote->wrkpage->EditWin, (remotey - remote->wrkpage->oy), remote->x, 'm' | COLOR_PAIR(colours[COLOR_GREEN][COLOR_YELLOW]) | A_BLINK);
		}
		}
		wrefresh(pages[cpage]->EditWin);
		refresh();
	}
	shutdown:
	Logo = drawexit_logo();
	wrefresh(Logo);
	endwin();
	return 0;
}

void read_config() {

	char *path = (char *)NULL;
	char *file = (char *)NULL;
	char *temp = (char *)NULL;

	FILE *fd = (FILE *)NULL;


	int num = 0, count = 0, offset = 0;
	int fxcount = 0, fycount = 0;

	path = getenv("HOME");
	file = (char *)malloc(strlen(path) + strlen("/.tetradrawrc") + 1);
	sprintf(file, "%s/.tetradrawrc", path);
	free(path);

	tet_opts.flip_fix = 0;
	tet_opts.auto_save = 0;
	tet_opts.auto_time = 0;
	tet_opts.save_sauce[0] = 'a';
	tet_opts.save_sauce[1] = 's';
	tet_opts.save_sauce[2] = 'k';
	tet_opts.save_sauce[3] = '\0';
	for(count = 0; count < 20; count++) {
		tet_opts.sauce_author[count] = ' ';
		tet_opts.sauce_group[count] = ' ';
	}

	for(count = 0; count < 35; count++) 
		tet_opts.sauce_title[count] = ' ';

	for(count = 0; count < 100; count++) {
		tet_opts.flip_x[count][0] = 32;
		tet_opts.flip_x[count][1] = 32;
		tet_opts.flip_y[count][0] = 32;
		tet_opts.flip_y[count][1] = 32;
	}
	
	for(count = 0; count < 21; count++) {
		tet_opts.highascii[count][0] = ' ';
		tet_opts.highascii[count][1] = ' ';
		tet_opts.highascii[count][2] = ' ';
		tet_opts.highascii[count][3] = ' ';
		tet_opts.highascii[count][4] = ' ';
		tet_opts.highascii[count][5] = ' ';
		tet_opts.highascii[count][6] = ' ';
		tet_opts.highascii[count][7] = ' ';
		tet_opts.highascii[count][8] = ' ';
		tet_opts.highascii[count][9] = ' ';
	}

	for(count = 0; count < 7; count++) 
		tet_opts.save_default[count] = ' ';


	if (!(fd = fopen(file, "r"))) {
		if (!(fd = fopen(file, "w"))) {
			endwin();
			printf("something is wrong im aborting\n");
			exit(-1);
		}
		fprintf(fd, "default_charset 0\n");
		fprintf(fd, "charset 0 \"ڿ��ĳô��\"\n");
		fprintf(fd, "charset 1 \"ɻȼͺ̹��\"\n");
		fprintf(fd, "charset 2 \"ոԾͳƵ��\"\n");
		fprintf(fd, "charset 3 \"ַӽĺǶ��\"\n");
		fprintf(fd, "charset 4 \"�����雜��\"\n");
		fprintf(fd, "charset 5 \"����������\"\n");
		fprintf(fd, "charset 6 \"� \"\n");
		fprintf(fd, "charset 7 \"\"\n");
		fprintf(fd, "charset 8 \"��������\"\n");
		fprintf(fd, "charset 9 \"���������\"\n");
		fprintf(fd, "charset 10 \"����������\"\n");
		fprintf(fd, "charset 11 \"����������\"\n");
		fprintf(fd, "charset 12 \"����������\"\n");
		fprintf(fd, "charset 13 \"����������\"\n");
		fprintf(fd, "charset 14 \"����������\"\n");
		fprintf(fd, "charset 15 \"/\\(){}[]`'\"\n");
		fprintf(fd, "charset 16 \"          \"\n");
		fprintf(fd, "charset 17 \"          \"\n");
		fprintf(fd, "charset 18 \"          \"\n");
		fprintf(fd, "charset 19 \"          \"\n");
		fprintf(fd, "charset 20 \"          \"\n");
		fprintf(fd, "\n");

		fprintf(fd, "statusbar_top 1\n");

		fprintf(fd, "show_logo 1\n");
		fprintf(fd, "logo_timeout 1\n");

		fprintf(fd, "sauce_author \"author\"\n");
		fprintf(fd, "sauce_group \"group\"\n");
		fprintf(fd, "sauce_title \"title\"\n");
		fprintf(fd, "save_sauce \"ask\"\n");
		fprintf(fd, "\n");

		fprintf(fd, "save_default \"ask\"\n");
		fprintf(fd, "auto_save 1\n");
		fprintf(fd, "auto_time 5\n");
		fprintf(fd, "\n");

		fprintf(fd, "flip_fix 1\n");

		fprintf(fd, "\n");
		fprintf(fd, "flip_x ' `\n");
		fprintf(fd, "flip_x ` '\n");
		fprintf(fd, "flip_x ( )\n"); 
		fprintf(fd, "flip_x ) (\n");
		fprintf(fd, "flip_x / \\\n");
		fprintf(fd, "flip_x \\ /\n");
		fprintf(fd, "flip_x < >\n");
		fprintf(fd, "flip_x > <\n");
		fprintf(fd, "flip_x [ ]\n");
		fprintf(fd, "flip_x ] [\n");
		fprintf(fd, "flip_x { }\n");
		fprintf(fd, "flip_x } {\n");
		fprintf(fd, "flip_x � �\n");
		fprintf(fd, "flip_x � �\n");
		fprintf(fd, "flip_x � �\n");
		fprintf(fd, "flip_x � �\n");
		fprintf(fd, "flip_x � �\n");
		fprintf(fd, "flip_x � �\n");
		fprintf(fd, "flip_x � �\n");
		fprintf(fd, "flip_x � �\n");
		fprintf(fd, "flip_x � �\n");
		fprintf(fd, "flip_x � �\n");
		fprintf(fd, "flip_x � �\n");
		fprintf(fd, "flip_x � �\n");
		fprintf(fd, "flip_x � �\n");
		fprintf(fd, "flip_x � �\n");
		fprintf(fd, "flip_x � �\n");
		fprintf(fd, "flip_x � �\n");
		fprintf(fd, "flip_x � �\n");
		fprintf(fd, "flip_x � �\n");
		fprintf(fd, "flip_x � �\n");
		fprintf(fd, "flip_x � �\n");
		fprintf(fd, "flip_x � �\n");
		fprintf(fd, "flip_x � �\n");
		fprintf(fd, "flip_x � �\n");
		fprintf(fd, "flip_x � �\n");
		fprintf(fd, "flip_x � �\n");
		fprintf(fd, "flip_x � �\n");
		fprintf(fd, "flip_x � �\n");
		fprintf(fd, "flip_x � �\n");
		fprintf(fd, "flip_x � �\n");
		fprintf(fd, "flip_x � �\n");
		fprintf(fd, "flip_x � �\n");

		fprintf(fd, "\n");
		fprintf(fd, "flip_y / \\\n");
		fprintf(fd, "flip_y \\ /\n");
		fprintf(fd, "flip_y � �\n");
		fprintf(fd, "flip_y � �\n");
		fprintf(fd, "flip_y � �\n");
		fprintf(fd, "flip_y � �\n");
		fprintf(fd, "flip_y � �\n");
		fprintf(fd, "flip_y � �\n");
		fprintf(fd, "flip_y � �\n");
		fprintf(fd, "flip_y � �\n");
		fprintf(fd, "flip_y � �\n");
		fprintf(fd, "flip_y � �\n");
		fprintf(fd, "flip_y � �\n");
		fprintf(fd, "flip_y � �\n");
		fprintf(fd, "flip_y � �\n");
		fprintf(fd, "flip_y � �\n");
		fprintf(fd, "flip_y � �\n");
		fprintf(fd, "flip_y � �\n");
		fprintf(fd, "flip_y � �\n");
		fprintf(fd, "flip_y � �\n");
		fprintf(fd, "flip_y � �\n");
		fprintf(fd, "flip_y � �\n");
		fprintf(fd, "flip_y � �\n");
		fprintf(fd, "flip_y � �\n");
		fprintf(fd, "flip_y � �\n");
		fprintf(fd, "flip_y � �\n");
		fprintf(fd, "flip_y � �\n");
		fprintf(fd, "flip_y � �\n");
		fprintf(fd, "\n");
		fclose(fd);
		fd = fopen(file, "r");
	}

	temp = (char *)malloc(1024 + 1);
	while ((temp = fgets(temp, 1024, fd)) != NULL) {
		offset = 0;
		if (!strncmp(temp, "statusbar_top", 13)) {
			while (!isdigit(*(temp + offset))) offset++;
			tet_opts.sb_top = *(temp + offset) - '0';
			continue;
		}
		if (!strncmp(temp, "default_charset", 15)) {
			while (!isdigit(*(temp + offset))) offset++;
			tet_opts.default_charset = *(temp + offset) - '0';
			if (tet_opts.default_charset<0 || tet_opts.default_charset > 19)
				tet_opts.default_charset = 0;
			continue;
		}
		if (!strncmp(temp, "auto_save", 9)) {
			while (!isdigit(*(temp + offset))) offset++;
			tet_opts.auto_save = *(temp + offset) - '0';
			continue;
		}
		if (!strncmp(temp, "auto_time", 9)) {
			while (!isdigit(*(temp + offset))) offset++;
			tet_opts.auto_time = *(temp + offset) - '0';
			continue;
		}
		if (!strncmp(temp, "save_sauce", 10)) { 
			while((*(temp + offset)) != '"') offset++;
			offset++;
			for(count = 0; count < 5 && *(temp + offset + count) != '"'; count++) 	tet_opts.save_sauce[count] = *(temp + offset + count);
			tet_opts.save_sauce[count] = '\0';
			continue;
		}
		if (!strncmp(temp, "show_logo", 7)) {
			while(!isdigit(*(temp + offset))) offset++;
			tet_opts.show_logo = *(temp + offset) - '0';
			continue;
		}
		if (!strncmp(temp, "logo_timeout", 11)) { 
			while (!isdigit(*(temp + offset))) offset++;
			tet_opts.logo_timeout = *(temp + offset) - '0';
			continue;
		}
		if (!strncmp(temp, "flip_fix", 8)) {
			while(!isdigit(*(temp + offset))) offset++;
			tet_opts.flip_fix = *(temp + offset) - '0';
			continue;
		}
		if (!strncmp(temp, "charset", 6)) {
			if (isdigit(temp[8])&&isdigit(temp[9])) 
				num = ((temp[8] - '0') * 10) + (temp[9] - '0');
			else if (isdigit(temp[8])) 
				num = (temp[8] - '0');
			while (*(temp + offset)!='"') offset++;
			offset++;
			for(count = 0; count < 10; count++) 
				tet_opts.highascii[num][count] = (char)*(temp + offset + count) & 0xFF;
			continue;
		}
		if (!strncmp(temp, "flip_x", 6)) {
			if (fxcount == 100) continue;
			while (isspace(*(temp + 7 + offset))) offset++;
			tet_opts.flip_x[fxcount][0] = *(temp + 7 + offset) & 0xFF;
			offset++;
			while (isspace(*(temp + 7 + offset))) offset++;
			tet_opts.flip_x[fxcount][1] = *(temp + 7 + offset) & 0xFF;
			fxcount++;
			continue;
		}
		if (!strncmp(temp, "flip_y", 6)) {
			if (fycount == 100) continue;
			while (isspace(*(temp + 7 + offset))) offset++;
			tet_opts.flip_y[fycount][0] = *(temp + 7 + offset) & 0xFF;
			offset++;
			while (isspace(*(temp + 7 + offset))) offset++;
			tet_opts.flip_y[fycount][1] = *(temp + 7 + offset) & 0xFF;
			fycount++;
			continue;
		}
		if (!strncmp(temp, "save_default", 11)) {
			while (*(temp + offset)!='"') offset++;
			offset++;
			for(count = 0; *(temp + offset + count) != '"' && count < 7; count++) tet_opts.save_default[count] = *(temp + offset + count);
			tet_opts.save_default[count] = '\0';
			continue;
		}
		if (!strncmp(temp, "sauce_author", 11)) {
			while (*(temp + offset)!='"') offset++;
			offset++;
			for(count = 0; *(temp + offset + count) != '"' && count < 20; count++) tet_opts.sauce_author[count] = *(temp + offset + count);
			count++;
			tet_opts.sauce_author[count] = '\0';
			continue;
		}
		if (!strncmp(temp, "sauce_group", 10)) {
			while (*(temp + offset)!='"') offset++;
			offset++;
			for(count = 0; *(temp + offset + count) != '"' && count < 20; count++) tet_opts.sauce_group[count] = *(temp + offset + count);
			tet_opts.sauce_group[count] = '\0';
			continue;
		}
		if (!strncmp(temp, "sauce_title", 10)) {
			while (*(temp + offset)!='"') offset++;
			offset++;
			for(count = 0; *(temp + offset + count) != '"' && count < 35; count++) tet_opts.sauce_title[count] = *(temp + offset + count);
			tet_opts.sauce_title[count] = '\0';
			continue;
		}
	}
	free(temp);
	fclose(fd);
	return;
}

void save_config() {
	char *path = (char *)NULL;
	char *file = (char *)NULL;
	FILE *fd = (FILE *)NULL;
	int count;

	path = getenv("HOME") != NULL ? getenv("HOME") : "/tmp";
	file = (char *)malloc(strlen(path) + strlen("/.tetradrawrc") + 1);
	sprintf(file, "%s/.tetradrawrc", path);
	fd = fopen(file, "w");
	free(path);
	free(file);
	if (!fd) 
		return;

	fprintf(fd, "default_charset %d\n", tet_opts.default_charset);
	fprintf(fd, "\n");
	for(count = 0; count < 21; count++) 
		fprintf(fd, "charset %d \"%c%c%c%c%c%c%c%c%c%c\"\n", count, tet_opts.highascii[count][0], tet_opts.highascii[count][1], tet_opts.highascii[count][2], tet_opts.highascii[count][3], tet_opts.highascii[count][4], tet_opts.highascii[count][5], tet_opts.highascii[count][6], tet_opts.highascii[count][7], tet_opts.highascii[count][8], tet_opts.highascii[count][9]);
	fprintf(fd, "\n");
	fprintf(fd, "statusbar_top %d\n", tet_opts.sb_top);
	fprintf(fd, "\n");
	fprintf(fd, "show_logo %d\n", tet_opts.show_logo);
	fprintf(fd, "logo_timeout %d\n", tet_opts.logo_timeout);
	fprintf(fd, "\n");
	fprintf(fd, "sauce_author \"%s\"\n", tet_opts.sauce_author);
	fprintf(fd, "sauce_group \"%s\"\n", tet_opts.sauce_group);
	fprintf(fd, "sauce_title \"%s\"\n", tet_opts.sauce_title);
	fprintf(fd, "save_sauce \"%s\"\n", tet_opts.save_sauce);
	fprintf(fd, "\n");
	fprintf(fd, "save_default \"%s\"\n", tet_opts.save_default);
	fprintf(fd, "auto_save %d\n", tet_opts.auto_save);
	fprintf(fd, "auto_time %d\n", tet_opts.auto_time);
	fprintf(fd, "\n");
	fprintf(fd, "flip_fix %d\n", tet_opts.flip_fix);
	for(count = 0;  count < 100; count++) 
		fprintf(fd, "flip_x %c %c\n", tet_opts.flip_x[count][0], tet_opts.flip_x[count][1]);
	fprintf(fd, "\n");
	for(count = 0;  count < 100; count++) 
		fprintf(fd, "flip_y %c %c\n", tet_opts.flip_y[count][0], tet_opts.flip_y[count][1]);
	fclose(fd);
	return;
}
