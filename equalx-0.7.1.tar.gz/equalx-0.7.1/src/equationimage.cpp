#include "equationimage.h"

EquationImage::EquationImage()
{
}
