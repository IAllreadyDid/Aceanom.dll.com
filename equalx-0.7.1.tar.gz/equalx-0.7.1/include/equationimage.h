#ifndef EQUATIONIMAGE_H
#define EQUATIONIMAGE_H

#include <QGraphicsPixmapItem>

class EquationImage : public QGraphicsPixmapItem
{
public:
    EquationImage();
};

#endif // EQUATIONIMAGE_H
