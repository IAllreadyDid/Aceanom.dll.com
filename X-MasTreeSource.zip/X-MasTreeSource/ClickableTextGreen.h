//
//  ClickableText.h
//
//  Created by Ben Haller on Tue Jul 15 2003.
//
//  This code is hereby released into the public domain.  Do with it as you wish.
//

// YES, I KNOW, I DONT NEED TWO COPIES OF THIS CUSTON CLASS. IM JUST TIRED AND DONT WANT TO WRITE MORE CODE.

#import <AppKit/AppKit.h>

@interface ClickableTextGreen : NSTextField
{
	BOOL beingClicked, beenClicked;
}

- (id)initWithFrame:(NSRect)frame;

@end
