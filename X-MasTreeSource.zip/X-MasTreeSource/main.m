//
//  main.m
//  X-MasTree
//
//  Created by John Schilling on 11/8/04.
//  Copyright John Schilling 2004. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
