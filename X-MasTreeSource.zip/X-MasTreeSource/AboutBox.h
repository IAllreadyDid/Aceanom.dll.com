//
//  AboutBox.h
//  X-MasTree
//
//  Created by John Schilling on 12/7/04.
//  Copyright 2004 John Schilling. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface AboutBox : NSWindowController {
        IBOutlet NSImageView        *_aboutView;
        IBOutlet NSTextField        *_appNameField;
        IBOutlet NSTextField        *_versionNumberField;
        NSTimer                     *_animeTimer;
        int                         _animeIndex;
        
}

- (IBAction)openAboutBoxWindow:(id)sender;
- (IBAction)openLink:(id)sender;

- (void)startAnimeTimer;
- (void)stopAnimeTimer;
- (void)animate:(NSTimer *)timer;

@end
