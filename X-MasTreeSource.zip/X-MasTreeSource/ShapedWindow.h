//
//  ShapedWindow.h
//  ShapedWindowz3
//
//  Created by John Schilling on 10/20/04.
//  Copyright 2004 John Schilling. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface ShapedWindow : NSWindow {

}

@end
