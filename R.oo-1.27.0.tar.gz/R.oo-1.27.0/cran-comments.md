This update addresses the deprecation of methods::getMethods() in R-devel.

I've verified that this submission does not negatively impact any of the 28 reverse dependencies on CRAN (n=22) and Bioconductor (n=6).
