# Platform

|field    |value                                                 |
|:--------|:-----------------------------------------------------|
|version  |R version 4.4.1 (2024-06-14)                          |
|os       |Rocky Linux 8.10 (Green Obsidian)                     |
|system   |x86_64, linux-gnu                                     |
|ui       |X11                                                   |
|language |en                                                    |
|collate  |en_US.UTF-8                                           |
|ctype    |en_US.UTF-8                                           |
|tz       |America/Los_Angeles                                   |
|date     |2024-11-01                                            |
|pandoc   |3.5 @ /software/c4/cbi/software/pandoc-3.5/bin/pandoc |

# Dependencies

|package     |old    |new         |Δ  |
|:-----------|:------|:-----------|:--|
|R.oo        |1.26.0 |1.26.0-9001 |*  |
|R.methodsS3 |1.8.2  |1.8.2       |   |

# Revdeps

## All (28)

|package          |version  |error |warning |note |
|:----------------|:--------|:-----|:-------|:----|
|ACNE             |0.9.1    |      |        |     |
|[affxparser](problems.md#affxparser)|1.78.0   |      |2       |3    |
|[aroma.affymetrix](problems.md#aromaaffymetrix)|3.2.2    |      |        |1    |
|aroma.apd        |0.7.0    |      |        |     |
|aroma.cn         |1.7.1    |      |        |     |
|[aroma.core](problems.md#aromacore)|3.3.1    |      |        |1    |
|[aroma.light](problems.md#aromalight)|3.36.0   |      |        |1    |
|[bioCancer](problems.md#biocancer)|1.34.0   |      |        |2    |
|calmate          |0.13.0   |      |        |     |
|[canceR](problems.md#cancer)|1.40.0   |      |1       |3    |
|delayed          |0.5.0    |      |        |     |
|knitrProgressBar |1.1.1    |      |        |     |
|[NCIgraph](problems.md#ncigraph)|1.54.0   |      |        |3    |
|neonstore        |0.5.1    |      |        |     |
|pathifier        |1.44.0   |      |        |     |
|PSCBS            |0.67.0   |      |        |     |
|[R.cache](problems.md#rcache)|0.16.0   |      |        |1    |
|R.devices        |2.17.2   |      |        |     |
|R.filesets       |2.15.1   |      |        |     |
|R.huge           |0.10.1   |      |        |     |
|[R.matlab](problems.md#rmatlab)|3.7.0    |      |        |1    |
|R.rsp            |0.46.0   |      |        |     |
|R.utils          |2.12.3   |      |        |     |
|roxygen2         |7.3.2    |      |        |     |
|rtf              |0.4-14.1 |      |        |     |
|[sBIC](problems.md#sbic)|0.2.0    |      |        |1    |
|SEMID            |0.4.1    |      |        |     |
|[WeibullFit](problems.md#weibullfit)|0.1.0    |      |        |1    |

