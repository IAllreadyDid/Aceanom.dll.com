#ifndef __MULTIDRAW_H_
#define __MULTIDRAW_H_
#include "editor.h"

typedef struct {
	int sock;
	int x;
	int y;
	int oy;
	int fg;
	int bg;
	int bold;
	int flash;
	int insert;
	char *localhandle;
	char *remotehandle;
	page *wrkpage;
	char *chat[8];
	int ccount;
} multid;

#define CMD_HELO 1 

#define CMD_TALK 2 

#define CMD_UP 3 
#define CMD_DOWN 4 
#define CMD_LEFT 5 
#define CMD_RIGHT 6 

#define CMD_COLOUR 7 
#define CMD_BOLD 8
#define CMD_FLASH 9
#define CMD_INSERT 10
#define CMD_POS 11

#define CMD_CINSERT 12
#define CMD_CDEL 13
#define CMD_CADD 14

#define CMD_STAMP 15 /* m/c, x1, y1, x2, y2, tx, ty, a/b, fx, fy */

#define CMD_FILLFG 16 /* fg, x1, y1, x2, y2 */
#define CMD_FILLBG 17 /* bg, x1, y1, x2, y2 */
#define CMD_FILLCH 18 /* ch, x1, y1, x2, y2 */

#define CMD_REPLACEFG 19 /* fg1, fg2, x1, y1, x2, y2 */
#define CMD_REPLACEBG 20 /* bg1, bg2, x1, y1, x2, y2 */
#define CMD_REPLACECHAR 21 /* ch1, ch2, x1, y1, x2, y2 */

#define CMD_DLINE 22 /* number of lines to delete */
#define CMD_ALINE 23 /* number of lines to add */
#define CMD_ILINE 24 /* number of lines to insert */

#endif
