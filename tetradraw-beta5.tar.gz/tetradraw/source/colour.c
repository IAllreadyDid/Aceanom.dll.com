#include <ncurses.h>
/* initializes colours[8][8] */

extern int colours[8][8];

void m_init_colours() {
	int count;

	if (has_colors()) {
		start_color();
		for(count = 1; count < COLOR_PAIRS; count++) {
			init_pair(count, count % COLORS, count / COLORS);
			colours[count % COLORS][count / COLORS] = count;
		}
		init_pair(colours[COLOR_WHITE][COLOR_BLACK], COLOR_BLACK, COLOR_BLACK);
		colours[COLOR_BLACK][COLOR_BLACK] = colours[COLOR_WHITE][COLOR_BLACK];
		colours[COLOR_WHITE][COLOR_BLACK] = -1;
	} else {
		/* Humm.. what to do ? */
	}
}

attr_t m_get_colour(int fg, int bg, int bold, int flash) {
	attr_t colour = 0;
	if(fg > 7 || bg > 7)
		return colour;
	if(colours[fg][bg] != -1) 
		colour |= COLOR_PAIR(colours[fg][bg]);
	else colour |= A_NORMAL;
	if(bold) colour |= A_BOLD;
	if(flash) colour |= A_BLINK;
	return colour;
}
