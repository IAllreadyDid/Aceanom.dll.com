/*
 * tv_editor.c by ttb (John McCutchan)
 * 
 * tetraview editor functions
 *
 */


#include <ncurses.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "global.h"
#include "keydefs.h"
#include "func.h"

#define PAGE_RESURRECT 0
#define PAGE_DECOMPOSE 1
#define PAGE_REPACKAGE 2

void move_down(page *, int );
void move_up(page *, int );
void move_left(page *, int );
void move_right(page *, int );

void line_add(page *, int );
void line_insert(page *, int );
void line_delete(page *, int );

void char_insert(page *, chtype );
void char_add(page *, chtype );
void char_add_l(page *, chtype );
void char_del(page *, int);

void draw_line(page *, int, int, int, int);

void update(page *);

page *page_factory(page *, int);

chtype attrib(page *, chtype );

void move_down(page *curpage, int num) {
	int count = 0;
	for(; count < num; count++)
	{
	if (curpage->y+1 >= 23) {
		if (!((curpage->oy + curpage->y + 1) < curpage->ly))
			line_add(curpage, 1);
		curpage->oy++;
	} else { 
		if (!((curpage->oy + curpage->y + 1) < curpage->ly))
			line_add(curpage, 1);
		curpage->y++;
	}
	}
	return;
}

void move_up(page *curpage, int num) {
	int count = 0;
	for(;count < num;count++)
	{
	if (curpage->y-1 < 0) {
		if (curpage->oy - 1 >= 0) 
			curpage->oy--;
	} else curpage->y--;
	}
	return;
}

void move_left(page *curpage, int num) {
	int count = 0;
	for(;count < num;count++) 
		if (curpage->x - 1 >= 0) curpage->x--; else break;
	return;
}

void move_right(page *curpage, int num) {
	int count = 0;
	for(;count < num;count++)
		if (curpage->x + 1 < 80) curpage->x++; else break;
	return;
}

void char_insert(page *curpage, chtype ch) {
		int countx = 78;
		int y = curpage->y + curpage->oy;
		for(; countx >= curpage->x;countx--) 
				curpage->buff[y][countx + 1] = curpage->buff[y][countx];
		curpage->buff[y][curpage->x] = ch | attrib(curpage, ch);
		move_right(curpage, 1);
		return;
}

void char_del(page *curpage, int num) {
		int count = 0;
		for(; count < num; count++) {
			int countx = curpage->x;
			int y = curpage->y + curpage->oy;
			curpage->buff[y][79] = ' ' | A_NORMAL;
			for(; countx < 79; countx++) 
					curpage->buff[y][countx] = curpage->buff[y][countx + 1];
		}
		return;
}

void char_add_l(page *curpage, chtype ch) {
	curpage->buff[curpage->oy + curpage->y][curpage->x] = ch | attrib(curpage, ch);
	if (curpage->x != 79) move_right(curpage, 1);
	else {
		move_down(curpage, 1);
		move_left(curpage, 79);
	}
	if (curpage->hy < curpage->oy + curpage->y) curpage->hy = curpage->oy + curpage->y;
}

void char_add(page *curpage, chtype ch) {
	curpage->buff[curpage->oy + curpage->y][curpage->x] = ch | attrib(curpage, ch);
	if (curpage->x != 79) move_right(curpage, 1);
	return;
}

void line_insert(page *curpage, int num) {
	int count = 0;
	int countl, countx;
	for(; count < num;count++) {
		curpage->ly++;
		curpage->buff = realloc(curpage->buff, sizeof(chtype *) * curpage->ly);
		curpage->buff[curpage->ly-1] = malloc(sizeof(chtype) * 80);
		for(countl = curpage->ly-1; countl > curpage->oy + curpage->y; countl--) 
				memmove(curpage->buff[countl], curpage->buff[countl-1], sizeof(chtype) * 80);
		for(countx = 0; countx < 80; countx++) 
			curpage->buff[countl][countx] = 32 | A_NORMAL;
	}
}

void line_delete(page *curpage, int num) {
	int count = 0;
	int countl;
	if (curpage->ly-1 > 0) {
		for(; count < num;count++) {
			for(countl = curpage->oy + curpage->y;countl < curpage->ly-1; countl++) 
				memmove(curpage->buff[countl], curpage->buff[countl+1],  sizeof(chtype) * 80);
			curpage->ly--;
			free(curpage->buff[curpage->ly]);
			while (curpage->ly <= curpage->oy + curpage->y) move_up(curpage, 1);
			curpage->buff = realloc(curpage->buff, sizeof(chtype *) * curpage->ly);
		}
	}
	return;
}

void line_add(page *curpage, int num) {
	int count = 0;
	int countx;
	for(; count < num;count++) {
		curpage->ly++;
		curpage->buff = realloc(curpage->buff, sizeof(chtype *) * curpage->ly);
		curpage->buff[curpage->ly-1] = malloc(sizeof(chtype) * 80);
		for(countx = 0; countx < 80;countx++) 
			curpage->buff[curpage->ly-1][countx] = 32 | A_NORMAL;
	}
	return;
}

void update(page *curpage) {
	int countx, county;
	werase(curpage->EditWin);
	for(county = 0; (curpage->oy + county) < curpage->ly;county++) 
		for(countx = 0; countx < 80;countx++) {
			mvwaddch(curpage->EditWin, county, countx, curpage->buff[curpage->oy + county][countx]);
		}
	return;
}

page *page_factory(page *curpage, int command) {
		page *newpage = (page *)NULL;
		if (command == PAGE_RESURRECT && !curpage) {
			newpage =  (page *)malloc(sizeof(page));
			newpage->x = 0;
			newpage->y = 0;
			newpage->oy = 0;
			newpage->ly = 0;
			newpage->fg = 7;
			newpage->bg = 0;
			newpage->bold = 0;
			newpage->flash = 0;
			newpage->hy = 0;
			newpage->insert = 0;
			newpage->hascii = 0;
			newpage->above = 0;
			newpage->below = 0;
			newpage->statusbar = 0;
			newpage->buff = (chtype **)NULL;
			newpage->EditWin = newwin(25, 80, 0, 0);

			line_add(newpage, 1);
			newpage->x = 0;
			newpage->y = 0;
			return newpage;
		} else if (command == PAGE_DECOMPOSE && curpage) {
			int count;
			delwin(curpage->EditWin);
			for(count = 0; count < curpage->ly; count++) 
					free(curpage->buff[count]);
			free(curpage->buff);
			free(curpage);
			return NULL;
		} else if (command == PAGE_REPACKAGE && curpage) {
			int count;
			for(count = 0; count < curpage->ly; count++)
				free(curpage->buff[count]);
			free(curpage->buff);
			curpage->buff = (chtype **)NULL;
			curpage->y = curpage->x = curpage->oy = curpage->ly = 0;
			line_add(curpage, 1);
			return curpage;
		}
		return NULL;
}

chtype attrib(page *curpage, chtype ch) {
	attr_t attr = 0;
	if (!isprint(ch)) attr |= A_ALTCHARSET;
	else attr |= A_NORMAL;
	attr |= m_get_colour(curpage->fg, curpage->bg, curpage->bold, curpage->flash);
	return attr;
}
