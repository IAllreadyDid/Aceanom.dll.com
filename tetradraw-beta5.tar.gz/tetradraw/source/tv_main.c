#include <stdlib.h>
#include <ncurses.h>
#include "editor.h"
#include "func.h"
#include "keydefs.h"


int colours[8][8];

char *select_file();
void tv_exit();

void tv_ansi(char *filename) {
	int count = 0;
	chtype key = 0;
	page *view_page = (page *)NULL;

	if(!filename) return;

	curs_set(0);
	view_page = load_ansi(filename);
	update(view_page);
	refresh();
	wrefresh(view_page->EditWin);

	while(1) {
		key = getch();
		switch(key) {
			case KEY_PAGEUP:
				for(count = 0; count < 24; count++) {
					if(view_page->oy > 0) view_page->oy--;
				}
				update(view_page);
				wrefresh(view_page->EditWin);
				break;
			case KEY_PAGEDOWN:
				for(count = 0; count < 24; count++) {
					if(view_page->oy < (view_page->ly - 24)) view_page->oy++;
				}
				update(view_page);
				wrefresh(view_page->EditWin);
				break;
			case KEY_UP:
				if(view_page->oy > 0) {
					view_page->oy--;
					update(view_page);
					wrefresh(view_page->EditWin);
				}
				break;
			case KEY_DOWN:
				if(view_page->oy < (view_page->ly - 24)) {
					view_page->oy++;
					update(view_page);
					wrefresh(view_page->EditWin);
				}
				break;
			case KEY_COLOUR:
			case 13:
				werase(view_page->EditWin);
				erase();
				wrefresh(view_page->EditWin);
				refresh();
				view_page = page_factory(view_page, PAGE_DECOMPOSE);
				return;
		}
	}
}

int main(int argc, char **argv) {
	char *filename = (char *)NULL;

	initscr();
	cbreak();
	noecho();
	nonl();
	keypad(stdscr, TRUE);
	curs_set(0);

	m_init_colours();

	define_key("\e\e", KEY_COLOUR);

	while(1) {
		filename = (char *)select_file();
		if(filename) {
			tv_ansi(filename);
			free(filename);
			filename = NULL;
		} else {
			erase();
			refresh();
			tv_exit();
			/* not reached */
		}
	}
	/* not reached */
}
