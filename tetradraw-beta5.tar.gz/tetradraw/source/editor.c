/*
 * editor.c by ttb (John McCutchan)
 * 
 * tetradraw editor functions
 *
 */


#include <ncurses.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "global.h"
#include "keydefs.h"
#include "func.h"

#define PAGE_RESURRECT 0
#define PAGE_DECOMPOSE 1
#define PAGE_REPACKAGE 2

chtype flip_x_fix(chtype );
chtype flip_y_fix(chtype );
page *flip_x(page *);
page *flip_y(page *);

void draw_block(page *, int, int, int, int);
void block_status(int , page *);
void block_command(page *);
void show_region(page *, page *);
page *copy_region(page *, int , int , int , int);
page *move_region(page *, int , int , int , int);
void stamp_region(page *, page *);

void replace_fg(page *, int, int, int, int, int, int);
void replace_bg(page *, int , int, int, int, int, int);
void replace_colour(page *, int, int, int, int, int, int, int, int);
void replace_char(page *, int, int, int, int, int, int);

void fill_fg(page *, int, int, int, int, int);
void fill_bg(page *, int, int, int, int, int);
void fill_colour(page *, int , int , int , int , int , int);
void fill_char(page *, int, int, int, int, int);

void move_down(page *, int );
void move_up(page *, int );
void move_left(page *, int );
void move_right(page *, int );

void line_add(page *, int );
void line_insert(page *, int );
void line_delete(page *, int );
void v_line_insert(page *, int );
void v_line_delete(page *, int );

void char_insert(page *, chtype );
void char_add(page *, chtype );
void char_add_l(page *, chtype );
void char_del(page *, int);

void draw_line(page *, int, int, int, int);

void update(page *);

page *page_factory(page *, int);

chtype attrib(page *, chtype );
chtype remote_attrib(chtype );

void move_down(page *curpage, int num) {
	int count = 0;
	char *m = (char *)NULL;
	for(; count < num; count++)
	{
	if (curpage->y+1 >= 23) {
		if (!((curpage->oy + curpage->y + 1) < curpage->ly))
			line_add(curpage, 1);
		curpage->oy++;
	} else { 
		if (!((curpage->oy + curpage->y + 1) < curpage->ly))
			line_add(curpage, 1);
		curpage->y++;
	}
	}
	if (remote) {
		m = (char *)malloc(1);
		m[0] = num;
		md_sendcmd(CMD_DOWN, m);
		free(m);
	}
	return;
}

void move_up(page *curpage, int num) {
	int count = 0;
	char *m = (char *)NULL;
	for(;count < num;count++)
	{
	if (curpage->y-1 < 0) {
		if (curpage->oy - 1 >= 0) 
			curpage->oy--;
	} else curpage->y--;
	}
	if (remote) {
		m = (char *)malloc(1);
		m[0] = num;
		md_sendcmd(CMD_UP, m);
		free(m);
	}
	return;
}

void move_left(page *curpage, int num) {
	int count = 0;
	char *m = (char *)NULL;
	for(;count < num;count++) 
		if (curpage->x - 1 >= 0) curpage->x--; else break;
	if (remote) {
		m = (char *)malloc(1);
		m[0] = num;
		md_sendcmd(CMD_LEFT, m);
		free(m);
	}
	return;
}

void move_right(page *curpage, int num) {
	int count = 0;
	char *m = (char *)NULL;
	for(;count < num;count++)
		if (curpage->x + 1 < 80) curpage->x++; else break;
	if (remote) {
		m = (char *)malloc(1);
		m[0] = num;
		md_sendcmd(CMD_RIGHT, m);
		free(m);
	}
	return;
}

void char_insert(page *curpage, chtype ch) {
		int countx = 78;
		int y = curpage->y + curpage->oy;
		char *m = (char *)NULL;
		for(; countx >= curpage->x;countx--) 
				curpage->buff[y][countx + 1] = curpage->buff[y][countx];
		curpage->buff[y][curpage->x] = ch | attrib(curpage, ch);
		move_right(curpage, 1);
		if (remote && remote->sock > 0) {
			m = (char *)malloc(1024);
			sprintf(m, "%c", (char)(ch & 0xFF));
			md_sendcmd(CMD_CINSERT, m);
			free(m);
			m = (char *)NULL;
		}
		return;
}

void char_del(page *curpage, int num) {
		int count = 0;
		char *m = (char *)NULL;
		for(; count < num; count++) {
			int countx = curpage->x;
			int y = curpage->y + curpage->oy;
			curpage->buff[y][79] = ' ' | A_NORMAL;
			for(; countx < 79; countx++) 
					curpage->buff[y][countx] = curpage->buff[y][countx + 1];
		}
		if (remote && remote->sock > 0) {
			m = (char *)malloc(1024);
			m[0] = num;
			m[1] = '\0';
			md_sendcmd(CMD_CDEL, m);
			free(m);
			m = NULL;
		}
		return;
}

void char_add_l(page *curpage, chtype ch) {
	curpage->buff[curpage->oy + curpage->y][curpage->x] = ch | attrib(curpage, ch);
	if (curpage->x != 79) move_right(curpage, 1);
	else {
		move_down(curpage, 1);
		move_left(curpage, 79);
	}
	if (curpage->hy < curpage->oy + curpage->y) curpage->hy = curpage->oy + curpage->y;
}

void char_add(page *curpage, chtype ch) {
	char *m = (char *)NULL;
	curpage->buff[curpage->oy + curpage->y][curpage->x] = ch | attrib(curpage, ch);
	if (remote && remote->sock > 0) {
		m = (char *)malloc(1024);
		sprintf(m, "%c", (char)(ch & 0xFF));
		md_sendcmd(CMD_CADD, m);
		free(m);
		m = NULL;
	}
	if (curpage->x != 79) move_right(curpage, 1);
	return;
}

void line_insert(page *curpage, int num) {
	int count = 0;
	int countl, countx;
	char *m = (char *)NULL;

	for(; count < num;count++) {
		curpage->ly++;
		curpage->hy++;
		curpage->buff = realloc(curpage->buff, sizeof(chtype *) * curpage->ly);
		curpage->buff[curpage->ly-1] = malloc(sizeof(chtype) * 80);
		for(countl = curpage->ly-1; countl > curpage->oy + curpage->y; countl--) 
				memmove(curpage->buff[countl], curpage->buff[countl-1], sizeof(chtype) * 80);
		for(countx = 0; countx < 80; countx++) 
			curpage->buff[countl][countx] = 32 | A_NORMAL;
	}
	if(remote && remote->sock > 0) {
		m = (char *)malloc(1024);
		m[0] = num;
		m[1] = '\0';
		md_sendcmd(CMD_ILINE, m);
		free(m);
		m = NULL;
	}
}

void line_delete(page *curpage, int num) {
	int count = 0;
	int countl;
	if (curpage->ly-1 > 0) {
		for(; count < num;count++) {
			for(countl = curpage->oy + curpage->y;countl < curpage->ly-1; countl++) 
				memmove(curpage->buff[countl], curpage->buff[countl+1],  sizeof(chtype) * 80);
			curpage->ly--;
			curpage->hy--;
			free(curpage->buff[curpage->ly]);
			while (curpage->ly <= curpage->oy + curpage->y) move_up(curpage, 1);
			curpage->buff = realloc(curpage->buff, sizeof(chtype *) * curpage->ly);
		}
	}
	return;
}

void line_add(page *curpage, int num) {
	int count = 0;
	int countx;
	for(; count < num;count++) {
		curpage->ly++;
		curpage->hy++;
		curpage->buff = realloc(curpage->buff, sizeof(chtype *) * curpage->ly);
		curpage->buff[curpage->ly-1] = malloc(sizeof(chtype) * 80);
		for(countx = 0; countx < 80;countx++) 
			curpage->buff[curpage->ly-1][countx] = 32 | A_NORMAL;
	}
	return;
}

void v_line_insert(page *curpage, int num) {
	int count = 0;
	int county, countx;
	for(; count < num; count++) {
		for(county = 0; county < curpage->ly; county++) {
			for(countx = 79; countx > curpage->x; countx--) {
				curpage->buff[county][countx] = curpage->buff[county][countx-1];
			}
			curpage->buff[county][curpage->x] = ' ' | A_NORMAL;
		}
	}
}

void v_line_delete(page *curpage, int num) {
	int count = 0;
	int county, countx;
	for(; count < num; count++) {
		for(county = 0; county < curpage->ly; county++)  
			for(countx = curpage->x+1; countx <= 80; countx++) 
				if(countx == 80) curpage->buff[county][countx-1] = ' ' | A_NORMAL;
			else curpage->buff[county][countx-1] = curpage->buff[county][countx];
	}
}

void update(page *curpage) {
	int countx, county;
	werase(curpage->EditWin);
	for(county = 0; (curpage->oy + county) < curpage->ly;county++) 
		for(countx = 0; countx < 80;countx++) {
			mvwaddch(curpage->EditWin, county, countx, curpage->buff[curpage->oy + county][countx]);
		}
	return;
}

page *page_factory(page *curpage, int command) {
		page *newpage = (page *)NULL;
		if (command == PAGE_RESURRECT && !curpage) {
			newpage =  (page *)malloc(sizeof(page));
			newpage->x = 0;
			newpage->y = 0;
			newpage->oy = 0;
			newpage->ly = 0;
			newpage->fg = 7;
			newpage->bg = 0;
			newpage->bold = 0;
			newpage->flash = 0;
			newpage->hy = 0;
			newpage->insert = 0;
			newpage->hascii = tet_opts.default_charset;
			newpage->above = 0;
			newpage->below = 0;
			newpage->statusbar = (tet_opts.sb_top) ? 0 : 24;
			newpage->buff = (chtype **)NULL;
			newpage->EditWin = newwin(24, 80, (newpage->statusbar == 0) ? 1 : 0, 0);

			line_add(newpage, 1);
			newpage->x = 0;
			newpage->y = 0;
			return newpage;
		} else if (command == PAGE_DECOMPOSE && curpage) {
			int count;
			delwin(curpage->EditWin);
			for(count = 0; count < curpage->ly; count++) 
					free(curpage->buff[count]);
			free(curpage->buff);
			free(curpage);
			return NULL;
		} else if (command == PAGE_REPACKAGE && curpage) {
			int count;
			for(count = 0; count < curpage->ly; count++)
				free(curpage->buff[count]);
			free(curpage->buff);
			curpage->buff = (chtype **)NULL;
			curpage->y = curpage->x = curpage->oy = curpage->ly = 0;
			line_add(curpage, 1);
			return curpage;
		}
		return NULL;
}

chtype attrib(page *curpage, chtype ch) {
	attr_t attr = 0;
	if (!isalpha(ch)) attr |= A_ALTCHARSET;
	else attr |= A_NORMAL;

	attr |= m_get_colour(curpage->fg, curpage->bg, curpage->bold, curpage->flash);
	return attr;
}

chtype remote_attrib(chtype ch) {
	attr_t attr = 0;
	if (!isalpha(ch)) attr |= A_ALTCHARSET;
	else attr |= A_NORMAL;
	attr |= m_get_colour(remote->fg, remote->bg, remote->bold, remote->flash);
	return attr;
}

chtype flip_x_fix(chtype fix) {
	int count = 0;
	int ch = 0;
	int pair = 0;
	int bold = 0;
	int flash;
	short fg, bg;
	attr_t goal;

	ch = fix & 0xFF;
	if (fix & A_BOLD) bold = 1; else bold = 0;
	if (fix & A_BLINK) flash = 1; else flash = 0;
	pair = PAIR_NUMBER(fix);
	pair_content(pair, &fg, &bg);

	goal = 32 | A_NORMAL;
	while(count<100) {
		if ((tet_opts.flip_x[count][0] & 0xFF) == ch && tet_opts.flip_x[count][0] != 32) {
			goal = (tet_opts.flip_x[count][1] & 0xFF);
			if (!isprint(tet_opts.flip_x[count][1] & 0xFF)) goal |= A_ALTCHARSET;
			goal |= m_get_colour(fg, bg, bold, flash);
			return goal;
		}
		count++;
	}
	return fix;
}

chtype flip_y_fix(chtype fix) {
	int count = 0;
	int ch;
	int pair;
	int bold;
	int flash;
	short fg, bg;
	attr_t goal;

	ch = fix & 0xFF;
	if (fix & A_BOLD) bold = 1; else bold = 0;
	if (fix & A_BLINK) flash = 1; else flash = 0;
	pair = PAIR_NUMBER(fix);
	pair_content(pair, &fg, &bg);

	goal = 32 | A_NORMAL;
	while(count<100) {
		if ((tet_opts.flip_y[count][0] & 0xFF) == ch && tet_opts.flip_y[count][0] != 32) {
			goal = (tet_opts.flip_y[count][1] & 0xFF);
			if(!isprint(tet_opts.flip_y[count][1] & 0xFF)) goal |= A_ALTCHARSET;
			goal |= m_get_colour(fg, bg, bold, flash);
			return goal;
		}
		count++;
	}
	return fix;
}

page *flip_x(page *buffer) {
	int county = 0;
	int countx = 0;
	int countxx = 0;
	int startx = 0;
	page *newpage = (page *)NULL;
	newpage = page_factory(newpage, PAGE_RESURRECT);
	line_add(newpage, buffer->ly - 1);

	for(county = 0; county < buffer->ly; county++) 
		for(countx = 0; countx < 80; countx++) 
				newpage->buff[county][countx] = -1;

	for(county = 0; county < buffer->ly; county++) 
		for(countx = 0; countx < 80;countx++)
			if (buffer->buff[county][countx] != -1)
				startx = countx;

	for(county = 0; county < buffer->ly; county++) {
		countxx = 0;
		for(countx = startx; countx >= 0; countx--) {
			newpage->buff[county][countxx] = (tet_opts.flip_fix) ? flip_x_fix(buffer->buff[county][countx]) : buffer->buff[county][countx];
			countxx++;
		}
	}
	newpage->ly = buffer->ly;
	newpage->above = buffer->above;
	newpage->below = buffer->below;
	buffer = page_factory(buffer, PAGE_DECOMPOSE);
	return newpage;
}


page *flip_y(page *buffer) {
	int county = 0;
	int countyy = 0;
	int countx = 0;
	page *newpage = (page *)NULL;

	newpage = page_factory(newpage, PAGE_RESURRECT);
	line_add(newpage, buffer->ly - 1);
	for(county = 0; county < buffer->ly; county++) 
		for(countx = 0; countx < 80; countx++) 
				newpage->buff[county][countx] = -1;

	countyy = buffer->ly - 1;

	for(county = 0; county < buffer->ly; county++) {
		for(countx = 0; countx < 80; countx++) 
			newpage->buff[county][countx] = (tet_opts.flip_fix) ? flip_y_fix(buffer->buff[countyy][countx]) : buffer->buff[countyy][countx];
		countyy--;
	}
	newpage->ly = buffer->ly;
	newpage->above = buffer->above;
	newpage->below = buffer->below;
	buffer = page_factory(buffer, PAGE_DECOMPOSE);
	return newpage;
}	

void show_region(page *editor, page *region) {
		int countx = 0, county = 0;

		if (region->above || region->below) {
			if (region->above) {
				for(county = editor->y; county < 24;county++) 
					if(county - editor->y  < region->ly) 
						for(countx = editor->x; countx < 80; countx++) {
							if((region->buff[county - editor->y][countx - editor->x]) != -1 && \
			region->buff[county - editor->y][countx - editor->x] != (32 | m_get_colour(COLOR_WHITE, COLOR_BLACK,0,0)))
								mvwaddch(editor->EditWin, county, countx, region->buff[county - editor->y][countx - editor->x]);
						}
			} else {
				for(county = editor->y; county < 24;county++) 
					if(county - editor->y  < region->ly) 
						for(countx = editor->x; countx < 80; countx++) {
							if((region->buff[county - editor->y][countx - editor->x]) != -1 && \
			editor->buff[editor->oy + county][countx] == (32 | m_get_colour(COLOR_WHITE, COLOR_BLACK, 0, 0)))
								mvwaddch(editor->EditWin, county, countx, region->buff[county - editor->y][countx - editor->x]);
						}
			}
			return;
		}
		for(county = editor->y; county < 24;county++) 
			if(county - editor->y < region->ly) 
				for(countx = editor->x; countx < 80; countx++) {
					if((region->buff[county - editor->y][countx - editor->x]) != -1 )
						mvwaddch(editor->EditWin, county, countx, region->buff[county - editor->y][countx - editor->x]);
				}
		return;
}

void stamp_region(page *editor, page *region) {
	int countx = 0;
	int county = 0;
	int ry = editor->y + editor->oy;

	if (region->above || region->below) {
		if (region->above) {
			for(county = 0; county < region->ly; county++) {
				if (county + ry >= editor->ly) line_add(editor, 1);
				for(countx = editor->x; countx < 80; countx++) 
					if (region->buff[county][countx - editor->x] != -1 && region->buff[county][countx - editor->x] != (32 | m_get_colour(COLOR_WHITE, COLOR_BLACK, 0, 0))) {
						editor->buff[ry + county][countx] = region->buff[county][countx - editor->x];
					if (ry  + county > editor->hy) editor->hy = ry + county;
					}
			}
		} else {
			for(county = 0; county < region->ly; county++) {
				if (county + ry >= editor->ly) line_add(editor, 1);
				for(countx = editor->x; countx < 80; countx++) 
					if (region->buff[county][countx - editor->x] != -1 && 
					editor->buff[ry + county][countx] == (32 | m_get_colour(COLOR_WHITE, COLOR_BLACK, 0, 0))) {
						editor->buff[ry + county][countx] = region->buff[county][countx - editor->x];
					if (ry  + county > editor->hy) editor->hy = ry + county;
				}
			}
		}
		return;
	}
	for(county = 0; county < region->ly; county++) {
		if (county + ry >= editor->ly) line_add(editor, 1);
		for(countx = editor->x; countx < 80; countx++) 
			if (region->buff[county][countx - editor->x] != -1) {
				editor->buff[ry + county][countx] = region->buff[county][countx - editor->x];
				if (ry  + county > editor->hy) editor->hy = ry + county;
			}
	}
	
}

void draw_block(page *buff, int x1, int y1, int x2, int y2) {
	int countx = 0, county = 0;
	int chr = 0;
	for(county = 0; county <= 24;county++) 
		if ((buff->oy + county) >= y1 && (buff->oy + county) <= y2)
			for(countx = 0; countx < 80; countx++) {
				if (countx <= x2 && countx >= x1) {
					chr = buff->buff[buff->oy + county][countx] & 0xFF;
					mvwaddch(buff->EditWin, county, countx, chr | A_REVERSE | A_ALTCHARSET);
				}
			}
	return;
}


void block_command(page *buff) {
	page *buffer = (page *)NULL;
	int x1 = 0, x2 = 0, y1 = 0, y2 = 0;
	int ch;
	int x, y, oy;
	int done = 0;
	int mode = 0;
	int ocpage = cpage;

	x = x1 = x2 = buff->x;
	y = buff->y;
	oy = buff->oy;
	y1 = y2 = oy + y;
	block_status(mode, buff);
	while (!done) {
		int cnt = 0;
		ch = md_getch();
		switch(ch) {
			case KEY_PAGEUP:
				for(cnt = 0; cnt < 23; cnt++) 
					if (y2-1 != y1-1) { move_up(buff, 1);y2--; }
				break;
			case KEY_PAGEDOWN:
				for(cnt = 0; cnt < 23; cnt++)
					if (y2+1 <= buff->ly) { move_down(buff, 1); y2++; }
				break;
			case KEY_HOME:
				x2 = x1;
				break;
			case KEY_END:
				x2 = 79;
				break;
			case KEY_UP:
				if (y2-1 != y1-1) { move_up(buff, 1);y2--; }
				break;
			case KEY_DOWN:
				if (y2+1 <= buff->ly) { move_down(buff, 1); y2++; }
				break;
			case KEY_LEFT:
				if (x2-1 != x1-1) { move_left(buff, 1); x2--; }
				break;
			case KEY_RIGHT:
				if (x2+1 != 80) { move_right(buff, 1); x2++; }
				break;
			case KEY_COLOUR:
				done = 1;
				break;
			case 'c':
			case 'C':
				buffer = copy_region(buff, x1, y1, x2, y2);
				mode = 1;
				done = 1;
				break;
			case 'u':
			case 'U':
				buffer = move_region(buff, x1, y1, x2, y2);
				mode = 1;
				done = 1;
				break;
			case 'f':
			case 'F':
				mode = 2;
				done = 1;
				break;
			case 'r':
			case 'R':
				mode = 3;
				done = 1;
				break;
		}
		update(buff);
		draw_block(buff, x1, y1, x2, y2);
		wrefresh(buff->EditWin);
	}
	buff->x = x;
	buff->y = y;
	buff->oy = oy;
	done = 0;
	if (mode) {
		block_status(mode, buff);
		refresh();
		switch (mode) {
			case 1:
				while (!done) {
					update(buff);
					show_region(buff, buffer);
					wmove(buff->EditWin, buff->y, buff->x);
					wrefresh(buff->EditWin);
					ch = md_getch();
					switch (ch) {
						case KEY_UP: move_up(buff, 1); break;
						case KEY_DOWN: move_down(buff, 1); break;
						case KEY_LEFT: move_left(buff, 1); break;
						case KEY_RIGHT: move_right(buff, 1); break;
						case 's':
						case 'S': stamp_region(buff, buffer); break;
						case 'x': 
						case 'X': buffer = flip_x(buffer); break;
						case 'y':
						case 'Y': buffer = flip_y(buffer); break;
						case 'a':
						case 'A': buffer->above = 1; buffer->below = 0; break;
						case 'b': 
						case 'B': buffer->below = 1; buffer->above = 0; break;
						case 'n':
						case 'N': buffer->above = buffer->below = 0; break;
						case '.': 
								cpage++;
								if (cpage > tpage) cpage = tpage;
								buff = pages[cpage];
								break;
						case ',': 
								cpage--;
								if (cpage < 0) cpage = 0;
								buff = pages[cpage];
								break;
						case KEY_COLOUR:
						case 13: done = 1; break;
					}
					block_status(mode, buff);
				}
				break;
			case 2:
				while (!done) {
					int ffg, fbg, fch;
					update(buff);
					draw_block(buff, x1, y1, x2, y2);
					wmove(buff->EditWin, buff->y, buff->x);
					wrefresh(buff->EditWin);
					ch = md_getch();
					switch (ch) {
						case 'f':
						case 'F': 
							select_f_fg(&ffg); 
							if (ffg != -1) 
								fill_fg(buff, ffg, x1, y1, x2, y2); 
							break;
						case 'b':
						case 'B': 
							select_f_bg(&fbg);
							if (fbg != -1) 
								fill_bg(buff, fbg, x1, y1, x2, y2); 
							break;
						case 'c': 
						case 'C': 
							select_f_char(&fch); 
							if (fch != -1) 
								fill_char(buff, fch, x1, y1, x2, y2);
							break;
						case KEY_COLOUR:
						case 13: done = 1; break;
					}
					block_status(mode, buff);
				}
				break;
			case 3:
				while (!done) {
					int rfg1, rfg2;
					int rbg1, rbg2;
					int rch1, rch2;
					update(buff);
					draw_block(buff, x1, y1, x2, y2);
					wmove(buff->EditWin, buff->y, buff->x);
					wrefresh(buff->EditWin);
					ch = md_getch();
					switch (ch) {
						case 'f':
						case 'F': 
							select_r_fg(&rfg1, &rfg2); 
							if (rfg1 != -1 && rfg2 != -1) 
								replace_fg(buff, rfg1, rfg2, x1, y1, x2, y2);
							break;
						case 'b':
						case 'B': 
							select_r_bg(&rbg1, &rbg2); 
							if (rbg1 != -1 && rbg2 != -1) 
								replace_bg(buff, rbg1, rbg2, x1, y1, x2, y2);
							break;
						case 'c': 
						case 'C': 
							select_r_char(&rch1, &rch2); 
							if (rch1 != -1 && rch2 != -1)
								replace_char(buff, rch1, rch2, x1, y1, x2, y2); 
							break;
						case KEY_COLOUR:
						case 13: done = 1; break;
					}
					block_status(mode, buff);
				}
				break;
		}
	}
	if (buffer != NULL) buffer = page_factory(buffer, PAGE_DECOMPOSE);
	cpage = ocpage;
	buff = pages[cpage];
	buff->x = x;
	buff->y = y;
	buff->oy = oy;
	return;
}

void block_status(int mode, page *buffer) {
	mvwprintw(stdscr, buffer->statusbar, 0, "                                                                                ");
	switch (mode) {
		case 1:
			mvwaddch(stdscr, buffer->statusbar, 0, '(' | m_get_colour(COLOR_CYAN, COLOR_BLACK, 0, 0));
			mvwprintw(stdscr, buffer->statusbar, 1, "paste");
			mvwaddch(stdscr, buffer->statusbar, 6, ')' | m_get_colour(COLOR_CYAN, COLOR_BLACK, 0, 0));
			mvwaddch(stdscr, buffer->statusbar, 8, 's' | m_get_colour(COLOR_YELLOW, COLOR_BLACK, 1, 0));
			mvwprintw(stdscr, buffer->statusbar, 9, "tamp flip ");
			mvwaddch(stdscr, buffer->statusbar, 19, 'x' | m_get_colour(COLOR_YELLOW, COLOR_BLACK, 1, 0));
			mvwaddch(stdscr, buffer->statusbar, 20, '/' | A_NORMAL);
			mvwaddch(stdscr, buffer->statusbar, 21, 'y' | m_get_colour(COLOR_YELLOW, COLOR_BLACK, 1, 0));
			mvwaddch(stdscr, buffer->statusbar, 23, 'a' | m_get_colour(COLOR_YELLOW, COLOR_BLACK, 1, 0));
			mvwprintw(stdscr, buffer->statusbar, 24, "bove");
			mvwaddch(stdscr, buffer->statusbar, 29, 'b' | m_get_colour(COLOR_YELLOW, COLOR_BLACK, 1, 0));
			mvwprintw(stdscr, buffer->statusbar, 30, "elow");
			mvwaddch(stdscr, buffer->statusbar, 35, 'n' | m_get_colour(COLOR_YELLOW, COLOR_BLACK, 1, 0));
			mvwprintw(stdscr, buffer->statusbar, 36, "ormal");
			mvwaddch(stdscr, buffer->statusbar, 42, ',' | m_get_colour(COLOR_YELLOW, COLOR_BLACK, 1, 0));
			mvwprintw(stdscr, buffer->statusbar, 43, "next page");
			mvwaddch(stdscr, buffer->statusbar, 53, '.' | m_get_colour(COLOR_YELLOW, COLOR_BLACK, 1, 0));
			mvwprintw(stdscr, buffer->statusbar, 54, "prev page");
			break;
		case 2:
			/* fill */
			mvwaddch(stdscr, buffer->statusbar, 0, '(' | m_get_colour(COLOR_CYAN, COLOR_BLACK, 0, 0));
			mvwaddch(stdscr, buffer->statusbar, 1, 'f' | m_get_colour(COLOR_CYAN, COLOR_BLACK, 0, 0));
			mvwprintw(stdscr, buffer->statusbar, 2, "ill");
			mvwaddch(stdscr, buffer->statusbar, 5, ')' | m_get_colour(COLOR_CYAN, COLOR_BLACK, 0, 0));
			mvwaddch(stdscr, buffer->statusbar, 7, 'f' | m_get_colour(COLOR_YELLOW, COLOR_BLACK, 1, 0));
			mvwprintw(stdscr, buffer->statusbar, 8, "oreground");
			mvwaddch(stdscr, buffer->statusbar, 18, 'b' | m_get_colour(COLOR_YELLOW, COLOR_BLACK, 1, 0));
			mvwprintw(stdscr, buffer->statusbar, 19, "ackground");
			mvwaddch(stdscr, buffer->statusbar, 29, 'c' | m_get_colour(COLOR_YELLOW, COLOR_BLACK, 1, 0));
			mvwprintw(stdscr, buffer->statusbar, 30, "haracter");
			break;
		case 3:
			/* replace */
			mvwaddch(stdscr, buffer->statusbar, 0, '(' | m_get_colour(COLOR_CYAN, COLOR_BLACK, 0, 0));
			mvwaddch(stdscr, buffer->statusbar, 1, 'r' | m_get_colour(COLOR_CYAN, COLOR_BLACK, 0, 0));
			mvwprintw(stdscr, buffer->statusbar, 2, "eplace");
			mvwaddch(stdscr, buffer->statusbar, 8, ')' | m_get_colour(COLOR_CYAN, COLOR_BLACK, 0, 0));
			mvwaddch(stdscr, buffer->statusbar, 10, 'f' |m_get_colour(COLOR_YELLOW, COLOR_BLACK, 1, 0));
			mvwprintw(stdscr, buffer->statusbar, 11, "oreground");
			mvwaddch(stdscr, buffer->statusbar, 21, 'b' | m_get_colour(COLOR_YELLOW, COLOR_BLACK, 1, 0));
			mvwprintw(stdscr, buffer->statusbar, 22, "ackground");
			mvwaddch(stdscr, buffer->statusbar, 32, 'c' | m_get_colour(COLOR_YELLOW, COLOR_BLACK, 1, 0));
			mvwprintw(stdscr, buffer->statusbar, 33, "haracter");
			break;
		default:
			/* block */
			mvwaddch(stdscr, buffer->statusbar, 0, '(' | m_get_colour(COLOR_CYAN, COLOR_BLACK, 0, 0));
			mvwprintw(stdscr, buffer->statusbar, 1, "block");
			mvwaddch(stdscr, buffer->statusbar, 6, ')' | m_get_colour(COLOR_CYAN, COLOR_BLACK, 0, 0));
			mvwaddch(stdscr, buffer->statusbar, 8, 'c' | m_get_colour(COLOR_YELLOW, COLOR_BLACK, 1, 0));
			mvwprintw(stdscr, buffer->statusbar, 9, "opy c");
			mvwaddch(stdscr, buffer->statusbar, 14, 'u' | m_get_colour(COLOR_YELLOW, COLOR_BLACK, 1, 0));
			mvwprintw(stdscr, buffer->statusbar, 15, "t ");
			mvwaddch(stdscr, buffer->statusbar, 17, 'f' | m_get_colour(COLOR_YELLOW, COLOR_BLACK, 1, 0));
			mvwprintw(stdscr, buffer->statusbar, 18, "ill");
			mvwaddch(stdscr, buffer->statusbar, 22, 'r' | m_get_colour(COLOR_YELLOW, COLOR_BLACK, 1, 0));
			mvwprintw(stdscr, buffer->statusbar, 23, "eplace");
			break;
	}
}

page *copy_region(page *buff, int x1, int y1, int x2, int y2) {
	page *buffer = (page *)NULL;
	int count = 0;
	int countx = 0;

	buffer = page_factory(buffer, PAGE_RESURRECT);
	line_add(buffer, y2 - y1);
	for(count = 0; count < y2 - y1 + 1; count++) {
		for(countx = 0; countx < 80; countx++) 
				buffer->buff[count][countx] = -1;
	}

	for(count = 0; count < y2 - y1 + 1; count++) 
		for(countx = 0; countx < 80; countx++) {
			if (countx >= x1 && countx <= x2) 
				buffer->buff[count][countx - x1] = buff->buff[count + y1][countx];
		}
	buffer->oy = 0;
	buffer->y = 0;
	buffer->x = 0;
	buffer->ly = y2 - y1 + 1;
	return buffer;
}

page *move_region(page *buff, int x1, int y1, int x2, int y2) {
	page *buffer = (page *)NULL;
	int  count = 0;
	int countx = 0;

	buffer = page_factory(buffer, PAGE_RESURRECT);
	line_add(buffer, y2 - y1);

	for(count = 0; count < y2 - y1 + 1; count++) {
		for(countx = 0; countx < 80; countx++) 
				buffer->buff[count][countx] = -1;
	}

	for(count = 0; count < y2 - y1 + 1; count++) 
		for(countx = 0; countx < 80; countx++) {
			if (countx >= x1 && countx <= x2) {
				buffer->buff[count][countx - x1] = buff->buff[count + y1][countx];
				buff->buff[count + y1][countx] = 32 | A_NORMAL;
			}
		}

	buffer->oy = 0;
	buffer->y = 0;
	buffer->x = 0;
	buffer->ly = y2 - y1 + 1;
	return buffer;
}

void replace_fg(page *buff, int fg1, int fg2, int x1, int y1, int x2, int y2) {
	int county, countx;
	int fg, bg, ch;
	int pair, bold;
	int flash;

	int f1fg, f1flash, f1bold;
	int f2fg, f2flash, f2bold;

	f1fg = f1flash = f1bold = 0;
	f2fg = f2flash = f2bold = 0;

	f1fg = fg1;
	f2fg = fg2;

	if (fg1 >= 16) {
		if (fg1 > 23) { 
			f1bold = 1;
			f1fg -= 24;
		} else {
			f1fg -= 16;
		}
		f1flash = 1;
	} else {
		if (fg1 > 7) { 
			f1bold = 1;
			f1fg -= 8;
		}
		f1flash = 0;
	}

	if (fg2 >= 16) {
		if (fg2 > 23) { 
			f2bold = 1;
			f2fg -= 24;
		} else {
			f2fg -= 16;
		}
		f2flash = 1;
	} else {
		if (fg2 > 7) { 
			f2bold = 1;
			f2fg -= 8;
		}
		f2flash = 0;
	}

	fg = 0;
	bg = 0;
	for(county = y1; county <= y2; county++) 
		for(countx = x1; countx <= x2; countx++) {
			ch = buff->buff[county][countx] & 0xFF;
			pair = PAIR_NUMBER(buff->buff[county][countx]);
			if (buff->buff[county][countx] & A_BOLD) bold = 1; else bold = 0;
			if (buff->buff[county][countx] & A_BLINK) flash = 1; else flash = 0;
			pair_content(pair, (short *)&fg, (short *)&bg);
			if (fg == f1fg && f1bold == bold && f1flash == flash) {
				if (!isprint(ch)) buff->buff[county][countx] |= A_ALTCHARSET;
				buff->buff[county][countx] = ch | m_get_colour(f2fg, bg, f2bold, f2flash);
			}
		}
}

void replace_bg(page *buff, int bg1, int bg2, int x1, int y1, int x2, int y2) {
	int county, countx;
	int fg, bg, ch;
	int pair, bold, flash;

	fg = bg = flash = bold = 0;
	for(county = y1; county <= y2; county++)
		for(countx = x1; countx <= x2; countx++) {
			ch = buff->buff[county][countx] & 0xFF;
			pair = PAIR_NUMBER(buff->buff[county][countx]);
			if (buff->buff[county][countx] & A_BOLD) bold = 1; else bold = 0;
			if (buff->buff[county][countx] & A_BLINK) flash = 1; else flash = 0;
			pair_content(pair, (short *)&fg, (short *)&bg);
			if (bg == bg1) {
				if (!isprint(ch)) buff->buff[county][countx] |= A_ALTCHARSET;
				buff->buff[county][countx] = ch | m_get_colour(fg, bg2, bold, flash);
			}
		}
}

void replace_char(page *buff, int ch1, int ch2, int x1, int y1, int x2, int y2) {
	int county, countx;
	int fg, bg, ch;
	int pair, bold, flash;

	for(county = y1; county <= y2; county++)
		for(countx = x1; countx <= x2; countx++) {
			ch = buff->buff[county][countx] & 0xFF;
			pair = PAIR_NUMBER(buff->buff[county][countx]);
			if (buff->buff[county][countx] & A_BOLD) bold = 1; else bold = 0;
			if (buff->buff[county][countx] & A_BLINK) flash = 1; else flash = 0;
			pair_content(pair, (short *)&fg, (short *)&bg);
			if (ch == ch1) ch = ch2;
			if(!isprint(ch))
				buff->buff[county][countx] |= A_ALTCHARSET;
			buff->buff[county][countx] |= ch;
			buff->buff[county][countx] |= m_get_colour(fg, bg, bold, flash);
		}
}

void replace_colour(page *buff, int fg1, int fg2, int bg1, int bg2, int x1, int y1, int x2, int y2) {
	replace_fg(buff, fg1, fg2, x1, y1, x2, y2);
	replace_bg(buff, bg1, bg2, x1, y1, x2, y2);
}

void fill_fg(page *buffer, int fg1, int x1, int y1, int x2, int y2) {
	int county, countx;
	int fg, bg, ch;
	int pair;
	int ffg, fflash, fbold;

	ffg = fflash = fbold = 0;

	ffg = fg1;

	if (fg1 >= 16) {
		if (fg1 > 23) { 
			fbold = 1;
			ffg -= 24;
		} else {
			ffg -= 16;
		}
		fflash = 1;
	} else {
		if (fg1 > 7) { 
			fbold = 1;
			ffg -= 8;
		}
		fflash = 0;
	}

	for(county = y1; county <= y2; county++) 
		for(countx = x1; countx <= x2; countx++) {
			ch = 32;
			fg = 0;
			bg = 0;
			ch = buffer->buff[county][countx] & 0xFF;
			pair = PAIR_NUMBER(buffer->buff[county][countx]);
			pair_content(pair, (short *)&fg, (short *)&bg);
			buffer->buff[county][countx] = ch;
			if (!isalpha(ch)) buffer->buff[county][countx] |= A_ALTCHARSET;
			buffer->buff[county][countx] |= m_get_colour(ffg, bg, fbold, fflash);
		}
}

void fill_bg(page *buffer, int bg1, int x1, int y1, int x2, int y2) {
	int county, countx;
	int fg, bg, ch;
	int pair;
	int bold;
	int flash;

	fg = 0;
	bg = 0;
	for(county = y1; county <= y2; county++) 
		for(countx = x1; countx <= x2; countx++) {
			ch = buffer->buff[county][countx] & 0xFF;
			pair = PAIR_NUMBER(buffer->buff[county][countx]);
			if (buffer->buff[county][countx] & A_BOLD) bold = 1; else bold = 0;
			if (buffer->buff[county][countx] & A_BLINK) flash = 1; else flash = 0;
			pair_content(pair, (short *)&fg, (short *)&bg);
			buffer->buff[county][countx] = ch;
			if(!isprint(ch)) buffer->buff[county][countx] |= A_ALTCHARSET;
			buffer->buff[county][countx] |= m_get_colour(fg, bg1, bold, flash);
		}
}

void fill_colour(page *buff, int fg1, int bg1, int x1, int y1, int x2, int y2) {
	fill_fg(buff, fg1, x1, y1, x2, y2);
	fill_bg(buff, bg1, x1, y1, x2, y2);
	return;
}

void fill_char(page *buffer, int ch, int x1, int y1, int x2, int y2) {
	int county, countx;
	int bold, pair, flash;
	short fg, bg;

	for(county = y1; county <= y2; county++)
		for(countx = x1; countx <= x2; countx++) {
			if (buffer->buff[county][countx] & A_BOLD) bold = 1; else bold = 0;
			if (buffer->buff[county][countx] & A_BLINK) flash = 1; else flash = 0;
			pair = PAIR_NUMBER(buffer->buff[county][countx]);
			pair_content(pair, (short *)&fg, (short *)&bg);
			buffer->buff[county][countx] = ch;
			if(!isprint(ch))
				buffer->buff[county][countx] |= A_ALTCHARSET;
			buffer->buff[county][countx] |= m_get_colour(fg, bg, bold, flash);
		}
}

void draw_line(page *buffer, int x1, int y1, int x2, int y2) {

	int t, distance;
	int x = 0, y = 0, delta_x, delta_y;
	int incx, incy;

	delta_x = x2-x1;
	delta_y = y2-y1;

	if (delta_x>0) incx = 1;
	else if (delta_x==0) incx = 0;
	else incx = -1;

	if (delta_y>0) incy = 1;
	else if (delta_y==0) incy = 0;
	else incy = -1;

	delta_x = abs(delta_x);
	delta_y = abs(delta_y);
	if (delta_x>delta_y) distance = delta_x;
	else distance = delta_y;

	for(t = 0; t <= distance + 1; t++) {
		mvwaddch(buffer->EditWin, x1, y1, 'D');
		x += delta_x;
		y += delta_y;
		if (x>distance) {
			x -= distance;
			x1 += incx;
		}
		if (y>distance) {
			y -= distance;
			y1 += incy;
		}
	}
}
