/*
 * interace.c by ttb (John McCutchan)
 *
 * tetradraw interface functions
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <unistd.h>
#include <dirent.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <menu.h>

#include "editor.h"
#include "global.h"
#include "ascii.h"
#include "keydefs.h"
#include "multidraw.h"
#include "func.h"

void drawstatus(page *curpage, int);
char **new_filelist(const char *, int *);
ITEM **create_items(char **, int );
int free_filelist(char **);
int free_items(ITEM **);
void grazzt(WINDOW *, char *, char *);
char *fchooser();
void chk_sauce(WINDOW *, const char *, char *, char *, char *);
void drawcolours(page *);
void drawcolours_stat(page *, WINDOW *cwin);

WINDOW *drawstart_logo();

void tet_options();

void help_screen();

void multidraw_screen(page *);

void select_f_fg(int *);
void select_f_bg(int *);
void select_f_char(int *);
void select_r_fg(int *, int *);
void select_r_bg(int *, int *);
void select_r_char(int *, int *);


void help_screen() {
	WINDOW *helpwin = (WINDOW *)NULL;
	int county = 0, countx = 0;
	int ch;

	helpwin = newwin(25, 80, 0, 0);
	werase(helpwin);

	for(; county < 20; county++)
		for(countx = 0; countx < 80; countx++) 
			mvwaddch(helpwin, county, countx, help_ansi[county][countx]);
	wrefresh(helpwin);
	while ((ch = md_getch())&&ch!=KEY_COLOUR&&ch!=13) continue;
}

void draw_options(WINDOW *optwin, int opt) {
	wattrset(optwin, m_get_colour(COLOR_BLACK, COLOR_BLACK, 1, 0));
	if (opt == 0) {
		wattrset(optwin, m_get_colour(COLOR_WHITE, COLOR_BLACK, 1, 0));
		mvwprintw(optwin, 10, 2, "show logo on startup");
		wattrset(optwin, m_get_colour(COLOR_BLACK, COLOR_BLACK, 1, 0));
	} else mvwprintw(optwin, 10, 2, "show logo on startup");
	if (opt == 1) {
		wattrset(optwin, m_get_colour(COLOR_WHITE, COLOR_BLACK, 1, 0));
		mvwprintw(optwin, 11, 2, "seconds to show logo");
		wattrset(optwin, m_get_colour(COLOR_BLACK, COLOR_BLACK, 1, 0));
	} else mvwprintw(optwin, 11, 2, "seconds to show logo");
	if (opt == 2) {
		wattrset(optwin, m_get_colour(COLOR_WHITE, COLOR_BLACK, 1, 0));
		mvwprintw(optwin, 12, 2, "default characterset");
		wattrset(optwin, m_get_colour(COLOR_BLACK, COLOR_BLACK,1, 0));
	} else mvwprintw(optwin, 12, 2, "default characterset");
	if (opt == 3) {
		wattrset(optwin, m_get_colour(COLOR_WHITE, COLOR_BLACK, 1, 0));
		mvwprintw(optwin, 13, 2, "fix characters when flipping");
		wattrset(optwin, m_get_colour(COLOR_BLACK, COLOR_BLACK, 1, 0));
	} else mvwprintw(optwin, 13, 2, "fix characters when flipping");
	if (opt == 4) {
		wattrset(optwin, m_get_colour(COLOR_WHITE, COLOR_BLACK, 1, 0));
		mvwprintw(optwin, 14, 2, "save sauce");
		wattrset(optwin, m_get_colour(COLOR_BLACK, COLOR_BLACK,1, 0));
	} else mvwprintw(optwin, 14, 2, "save sauce");
	if (opt == 5) {
		wattrset(optwin, m_get_colour(COLOR_WHITE, COLOR_BLACK, 1, 0));
		mvwprintw(optwin, 15, 2, "auto save");
		wattrset(optwin, m_get_colour(COLOR_BLACK, COLOR_BLACK,1, 0));
	} else mvwprintw(optwin, 15, 2, "auto save");
	if (opt == 6) {
		wattrset(optwin, m_get_colour(COLOR_WHITE, COLOR_BLACK, 1, 0));
		mvwprintw(optwin, 16, 2, "auto save time");
		wattrset(optwin, m_get_colour(COLOR_BLACK, COLOR_BLACK,1, 0));
	} else mvwprintw(optwin, 16, 2, "auto save time");
		
	if (opt == 7) {
		wattrset(optwin, m_get_colour(COLOR_WHITE, COLOR_BLACK, 1, 0));
		mvwprintw(optwin, 17, 2, "default save type");
		wattrset(optwin, m_get_colour(COLOR_BLACK, COLOR_BLACK,1, 0));
	} else mvwprintw(optwin, 17, 2, "default save type");
	if (opt == 8) {
		wattrset(optwin, m_get_colour(COLOR_WHITE, COLOR_BLACK, 1, 0));
		mvwprintw(optwin, 18, 2, "default sauce author");
		wattrset(optwin, m_get_colour(COLOR_BLACK, COLOR_BLACK,1, 0));
	} else mvwprintw(optwin, 18, 2, "default sauce author");
	if (opt == 9) {
		wattrset(optwin, m_get_colour(COLOR_WHITE, COLOR_BLACK, 1, 0));
		mvwprintw(optwin, 19, 2, "default sauce group");
		wattrset(optwin, m_get_colour(COLOR_BLACK, COLOR_BLACK,1, 0));
	} else mvwprintw(optwin, 19, 2, "default sauce group");
	if (opt == 10) {
		wattrset(optwin, m_get_colour(COLOR_WHITE, COLOR_BLACK, 1, 0));
		mvwprintw(optwin, 20, 2, "default sauce title");
		wattrset(optwin, m_get_colour(COLOR_BLACK, COLOR_BLACK, 1, 0));
	} else mvwprintw(optwin, 20, 2, "default sauce title");

	if (tet_opts.show_logo) {
		wattrset(optwin, m_get_colour(COLOR_GREEN, COLOR_BLACK, 0, 0));
		mvwprintw(optwin, 10, 40, "yes");
		wattrset(optwin, A_NORMAL);
		mvwprintw(optwin, 10, 45, "no");
	} else {
		wattrset(optwin, A_NORMAL);
		mvwprintw(optwin, 10, 40, "yes");
		wattrset(optwin, m_get_colour(COLOR_GREEN, COLOR_BLACK, 0, 0));
		mvwprintw(optwin, 10, 45, "no");
	}
	wattrset(optwin, A_NORMAL);
	mvwprintw(optwin, 11, 40, "%d", tet_opts.logo_timeout);
	mvwprintw(optwin, 12, 40, "%2d", tet_opts.default_charset);
	if (tet_opts.flip_fix == 1) {
		wattrset(optwin, m_get_colour(COLOR_GREEN, COLOR_BLACK, 0, 0));
		mvwprintw(optwin, 13, 40, "yes");
		wattrset(optwin, A_NORMAL);
		mvwprintw(optwin, 13, 45, "no");
	} else {
		wattrset(optwin, A_NORMAL);
		mvwprintw(optwin, 13, 40, "yes");
		wattrset(optwin, m_get_colour(COLOR_GREEN, COLOR_BLACK, 0, 0));
		mvwprintw(optwin, 13, 45, "no");
	}
	if (!strcmp(tet_opts.save_sauce, "ask")) {
		wattrset(optwin, m_get_colour(COLOR_GREEN, COLOR_BLACK, 0, 0));
		mvwprintw(optwin, 14, 40, "ask");
		wattrset(optwin, A_NORMAL);
		mvwprintw(optwin, 14, 45, "yes");
		mvwprintw(optwin, 14, 50, "no");
	} else if (!strcmp(tet_opts.save_sauce, "no")) {
		wattrset(optwin, A_NORMAL);
		mvwprintw(optwin, 14, 40, "ask");
		mvwprintw(optwin, 14, 45, "yes");
		wattrset(optwin, m_get_colour(COLOR_GREEN, COLOR_BLACK, 0, 0));
		mvwprintw(optwin, 14, 50, "no");
	} else {
		wattrset(optwin, A_NORMAL);
		mvwprintw(optwin, 14, 40, "ask");
		mvwprintw(optwin, 14, 50, "no");
		wattrset(optwin, m_get_colour(COLOR_GREEN, COLOR_BLACK, 0, 0));
		mvwprintw(optwin, 14, 45, "yes");
	}
	if (tet_opts.auto_save) {
		wattrset(optwin, m_get_colour(COLOR_GREEN, COLOR_BLACK, 0, 0));
		mvwprintw(optwin, 15, 40, "yes");
		wattrset(optwin, A_NORMAL);
		mvwprintw(optwin, 15, 45, "no");
	} else {
		wattrset(optwin, A_NORMAL);
		mvwprintw(optwin, 15, 40, "yes");
		wattrset(optwin, m_get_colour(COLOR_GREEN, COLOR_BLACK, 0, 0));
		mvwprintw(optwin, 15, 45, "no");
	}
	wattrset(optwin, A_NORMAL);
	mvwprintw(optwin, 16, 40, "%d", tet_opts.auto_time);
	if (!strcmp(tet_opts.save_default, "ask")) {
		wattrset(optwin, m_get_colour(COLOR_GREEN, COLOR_BLACK, 0, 0));
		mvwprintw(optwin, 17, 40, "ask");
		wattrset(optwin, A_NORMAL);
		mvwprintw(optwin, 17, 45, "ansi");
		mvwprintw(optwin, 17, 50, "ascii");
	} else if (!strcmp(tet_opts.save_default, "ansi")) {
		wattrset(optwin, m_get_colour(COLOR_GREEN, COLOR_BLACK, 0, 0));
		mvwprintw(optwin, 17, 45, "ansi");
		wattrset(optwin, A_NORMAL);
		mvwprintw(optwin, 17, 40, "ask");
		mvwprintw(optwin, 17, 50, "ascii");
	} else {
		wattrset(optwin, m_get_colour(COLOR_GREEN, COLOR_BLACK, 0, 0));
		mvwprintw(optwin, 17, 50, "ascii");
		wattrset(optwin, A_NORMAL);
		mvwprintw(optwin, 17, 45, "ansi");
		mvwprintw(optwin, 17, 40, "ask");
	}
	wattrset(optwin, A_NORMAL);
	mvwprintw(optwin, 18, 40, "%s", tet_opts.sauce_author);
	mvwprintw(optwin, 19, 40, "%s", tet_opts.sauce_group);
	mvwprintw(optwin, 20, 40, "%s", tet_opts.sauce_title);
	return;
}

/* opt #
0 - show_logo -- on / off
1 - logo_timeout -- numbers (seconds)
2 - default_charset -- numbers (1-20)
3 - flip_fix -- on / off
4 - save_saucec -- on / off / ask
5 - auto save -- on / off
6 - auto_time -- numbers (seconds)
7 - default save file type -- ansi / ascii / ask
8 - default sauce author -- text field
9 - defualt sauce group -- text field
10 - default sauce title -- text field
*/

void opt_input(WINDOW *optwin, int opt) {
	int ch = 0;
	int oldnum = 0;
	int c = 0;
	char *oldstring = (char *)NULL;
	char temp[2];
	int done = 0;
	switch (opt) {
		case 0:
			oldnum = tet_opts.show_logo;
			while (!done) {
				switch(md_getch()) {
					case -1:
						break;
					case KEY_COLOUR:
						tet_opts.show_logo = oldnum;
						done = 1;
						break;
					case 13:
						done = 1;
						break;
					case KEY_LEFT:
						tet_opts.show_logo = 1;
						break;
					case KEY_RIGHT:
						tet_opts.show_logo = 0;
						break;
				}
				draw_options(optwin, opt);
				wrefresh(optwin);
			}
			break;
		case 1:
			oldnum = tet_opts.logo_timeout;
			while (!done) {
				switch (ch = md_getch()) {
					case -1:
						break;
					case KEY_COLOUR:
						tet_opts.logo_timeout = oldnum;
						done = 1;
						break;
					case 13:
						done = 1;
						break;
					default:
						if (isdigit(ch)) tet_opts.logo_timeout = ch - '0';
				}
				draw_options(optwin, opt);
				wrefresh(optwin);
			}
			break;
		case 2:
			oldnum = tet_opts.default_charset;
			temp[0] = ' ';
			temp[1] = ' ';
			c = 0;
			mvwaddch(optwin, 12, 40, ' ');
			mvwaddch(optwin, 12, 41, ' ');
			mvwaddch(optwin, 12, 40, temp[0]);
			mvwaddch(optwin, 12, 41, temp[1]);
			wrefresh(optwin);
			while (!done) {
				switch(ch = md_getch()) {
					case -1:
						break;
					case KEY_COLOUR:
						tet_opts.default_charset = oldnum;
						done = 1;
						break;
					case 13:
						if (isdigit(temp[0]) || isdigit(temp[1])) {
							if (isdigit(temp[1])) {
								tet_opts.default_charset = (temp[0] - '0') * 10;
								tet_opts.default_charset += (temp[1] - '0');
							} else tet_opts.default_charset = temp[0] - '0';
						}
						if (tet_opts.default_charset>20) 
							tet_opts.default_charset = 20;
						done = 1;
						break;
					case KEY_BACKSPACE:
						temp[c] = ' ';
						if (c-1==0) c--;
						break;
					default:
						if (isdigit(ch)) {
							temp[c] = ch;
							if (c+1==1) c++;
						}
						break;
				}
				mvwaddch(optwin, 12, 40, ' ');
				mvwaddch(optwin, 12, 41, ' ');
				mvwaddch(optwin, 12, 40, temp[0]);
				mvwaddch(optwin, 12, 41, temp[1]);
				wrefresh(optwin);
			}
			break;
		case 3:
			oldnum = tet_opts.flip_fix;
			while (!done) {
				switch (md_getch()) {
					case -1:
						break;
					case KEY_COLOUR:
						tet_opts.flip_fix = oldnum;
						done = 1;
						break;
					case 13:
						done = 1;
						break;
					case KEY_LEFT:
						tet_opts.flip_fix = 1;
						break;
					case KEY_RIGHT:
						tet_opts.flip_fix = 0;
						break;
				}
				draw_options(optwin, opt);
				wrefresh(optwin);
			}
			break;
		case 4:
			if (!strcmp(tet_opts.save_sauce, "ask"))  {
				c = 0;
			} else if (!strcmp(tet_opts.save_sauce, "yes"))  {
				c = 1;
			} else {
				c = 2;
			}
			oldnum = c;
			while (!done) {
				switch(md_getch()) {
					case -1:
						break;
					case KEY_COLOUR:
						done = 1;
						break;
					case 13:
						if (oldnum != c) {
							if (c==0) {
								tet_opts.save_sauce[0] = 'a';
								tet_opts.save_sauce[1] = 's';
								tet_opts.save_sauce[2] = 'k';
								tet_opts.save_sauce[3] = '\0';
							} else if (c==1) {
								tet_opts.save_sauce[0] = 'y';
								tet_opts.save_sauce[1] = 'e';
								tet_opts.save_sauce[2] = 's';
								tet_opts.save_sauce[3] = '\0';
							} else {
								tet_opts.save_sauce[0] = 'n';
								tet_opts.save_sauce[1] = 'o';
								tet_opts.save_sauce[2] = '\0';
							}
						}
						done = 1;
						break;
					case KEY_LEFT:
						if (c-1>=0) c--;
						break;
					case KEY_RIGHT:
						if (c+1<=2) c++;
						break;
				}
				if (c==0) {
					wattrset(optwin, m_get_colour(COLOR_GREEN, COLOR_BLACK, 0, 0));
					mvwprintw(optwin, 14, 40, "ask");
					wattrset(optwin, A_NORMAL);
					mvwprintw(optwin, 14, 45, "yes");
					mvwprintw(optwin, 14, 50, "no");
				} else if (c==1) {
					wattrset(optwin, A_NORMAL);
					mvwprintw(optwin, 14, 40, "ask");
					wattrset(optwin, m_get_colour(COLOR_GREEN, COLOR_BLACK, 0, 0));
					mvwprintw(optwin, 14, 45, "yes");
					wattrset(optwin, A_NORMAL);
					mvwprintw(optwin, 14, 50, "no");
				} else {
					wattrset(optwin, A_NORMAL);
					mvwprintw(optwin, 14, 40, "ask");
					mvwprintw(optwin, 14, 45, "yes");
					wattrset(optwin, m_get_colour(COLOR_GREEN, COLOR_BLACK, 0, 0));
					mvwprintw(optwin, 14, 50, "no");
					wattrset(optwin, A_NORMAL);
				}
				wrefresh(optwin);
			}
			break;
		case 5:
			oldnum = tet_opts.auto_save;
			while (!done) {
				switch (md_getch()) {
					case -1:
						break;
					case KEY_COLOUR:
						tet_opts.auto_save = oldnum;
						done = 1;
						break;
					case 13:
						done = 1;
						break;
					case KEY_LEFT:
						tet_opts.auto_save = 1;
						break;
					case KEY_RIGHT:
						tet_opts.auto_save = 0;
						break;
				}
				draw_options(optwin, opt);
				wrefresh(optwin);
			}
			break;
		case 6:
			oldnum = tet_opts.auto_time;
			while (!done) {
				switch ((ch = md_getch())) {
					case -1:
						break;
					case KEY_COLOUR:
						tet_opts.auto_time = oldnum;
						done = 1;
						break;
					case 13:
						done = 1;
						break;
					default:
						if (isdigit(ch)) 
							tet_opts.auto_time = ch - '0';
						break;
				}
				draw_options(optwin, opt);
				wrefresh(optwin);
			}
			break;
		case 7:
			if (!strcmp(tet_opts.save_default, "ask")) {
				c = 0;
			} else if (!strcmp(tet_opts.save_default, "ansi")) {
				c = 1;
			} else {
				c = 2;
			}
			oldnum = c;
			while (!done) {
				switch (md_getch()) {
					case -1:
						break;
					case KEY_COLOUR:
						done = 1;
						break;
					case 13:
						if (oldnum != c) {
							if (c==0) {
								tet_opts.save_default[0] = 'a';
								tet_opts.save_default[1] = 's';
								tet_opts.save_default[2] = 'k';
								tet_opts.save_default[3] = '\0';
							} else if (c==1) {
								tet_opts.save_default[0] = 'a';
								tet_opts.save_default[1] = 'n';
								tet_opts.save_default[2] = 's';
								tet_opts.save_default[3] = 'i';
								tet_opts.save_default[4] = '\0';
							} else {
								tet_opts.save_default[0] = 'a';
								tet_opts.save_default[1] = 's';
								tet_opts.save_default[2] = 'c';
								tet_opts.save_default[3] = 'i';
								tet_opts.save_default[4] = 'i';
								tet_opts.save_default[5] = '\0';
							}
						}
						done = 1;
						break;
					case KEY_LEFT:
						if (c-1>=0) c--;
						break;
					case KEY_RIGHT:
						if (c+1<=2) c++;
						break;
				}
				if (c==0) {
					wattrset(optwin, m_get_colour(COLOR_GREEN, COLOR_BLACK, 0, 0));
					mvwprintw(optwin, 17, 40, "ask");
					wattrset(optwin, A_NORMAL);
					mvwprintw(optwin, 17, 50, "ascii");
					mvwprintw(optwin, 17, 45, "ansi");
				} else if (c==1) {
					wattrset(optwin, m_get_colour(COLOR_GREEN, COLOR_BLACK, 0, 0));
					mvwprintw(optwin, 17, 45, "ansi");
					wattrset(optwin, A_NORMAL);
					mvwprintw(optwin, 17, 50, "ascii");
					mvwprintw(optwin, 17, 40, "ask");
				} else {
					wattrset(optwin, m_get_colour(COLOR_GREEN, COLOR_BLACK, 0, 0));
					mvwprintw(optwin, 17, 50, "ascii");
					wattrset(optwin, A_NORMAL);
					mvwprintw(optwin, 17, 45, "ansi");
					mvwprintw(optwin, 17, 40, "ask");
				}
				wrefresh(optwin);
			}
			break;
		case 8:
			oldstring = (char *)malloc(strlen(tet_opts.sauce_author) + 1);
			strcpy(oldstring, tet_opts.sauce_author);
			c = strlen(tet_opts.sauce_author);
			while (!done) {
				switch ((ch = md_getch())) {
					case -1:
						break;
					case KEY_COLOUR:
						strcpy(tet_opts.sauce_author, oldstring);
						free(oldstring);
						done = 1;
						break;
					case 13:
						free(oldstring);
						done = 1;
						break;
					case KEY_BACKSPACE:
						tet_opts.sauce_author[c] = '\0';
						if (c-1>=0) c--;
						tet_opts.sauce_author[c] = ' ';
						break;
					default:
						if (isprint(ch)) {
							tet_opts.sauce_author[c] = ch;
							if (c+1<20) c++;
							tet_opts.sauce_author[c] = '\0';
						}
						break;
				}
				draw_options(optwin, opt);
				wrefresh(optwin);
			}
			break;
		case 9:
			oldstring = (char *)malloc(strlen(tet_opts.sauce_group) + 1);
			strcpy(oldstring, tet_opts.sauce_group);
			c = strlen(tet_opts.sauce_group);
			while (!done) {
				switch ((ch = md_getch())) {
					case -1:
						break;
					case KEY_COLOUR:
						strcpy(tet_opts.sauce_group, oldstring);
						free(oldstring);
						done = 1;
						break;
					case 13:
						free(oldstring);
						done = 1;
						break;
					case KEY_BACKSPACE:
						tet_opts.sauce_group[c] = '\0';
						if (c-1>=0) c--;
						tet_opts.sauce_group[c] = ' ';
						break;
					default:
						if (isprint(ch)) {
							tet_opts.sauce_group[c] = ch;
							if (c+1<20) c++;
							tet_opts.sauce_group[c] = '\0';
						}
						break;
				}
				draw_options(optwin, opt);
				wrefresh(optwin);
			}
			break;
		case 10:
			oldstring = (char *)malloc(strlen(tet_opts.sauce_title) + 1);
			strcpy(oldstring, tet_opts.sauce_title);
			c = strlen(tet_opts.sauce_title);
			while (!done) {
				switch ((ch = md_getch())) {
					case -1:
						break;
					case KEY_COLOUR:
						strcpy(tet_opts.sauce_title, oldstring);
						free(oldstring);
						done = 1;
						break;
					case 13:
						free(oldstring);
						done = 1;
						break;
					case KEY_BACKSPACE:
						tet_opts.sauce_title[c] = '\0';
						if (c-1>=0) c--;
						tet_opts.sauce_title[c] = ' ';
						break;
					default:
						if (isprint(ch)) {
							tet_opts.sauce_title[c] = ch;
							if (c+1<35) c++;
							tet_opts.sauce_title[c] = '\0';
						}
						break;
				}
				draw_options(optwin, opt);
				wrefresh(optwin);
			}
			break;
	}
}

void tet_options() {
	WINDOW *optwin = (WINDOW *)NULL; /* the options window */
	int ch; /* for input */
	int opt; /* opt level counter */
	int done = 0; /* input test */
	int countx = 0, county = 0; /* for displaying ansi */

	optwin = newwin(25, 80, 0, 0);
	werase(optwin);

	for(county = 0; county < 9; county++) 
		for(countx = 0; countx < 80; countx++)
			mvwaddch(optwin, county, countx, options_ansi[county][countx]);

	opt = 0;
	draw_options(optwin, opt);
	wrefresh(optwin);
	while (!done) {
		ch = md_getch();
		switch (ch) {
			case KEY_UP:
				if (opt - 1 >= 0) opt--;
				break;
			case KEY_DOWN:
				if (opt + 1 < 11) opt++;
				break;
			case KEY_LEFT:
				break;
			case KEY_RIGHT:
				break;
			case 13:
				opt_input(optwin, opt);
				break;
			case KEY_COLOUR:
				done = 1;
				break;
			case KEY_ASAVE:
				save_config();
				done = 1;
				break;
			default:
				break;
		}
		draw_options(optwin, opt);
		wrefresh(optwin);
	}
	delwin(optwin);
	return;
}

WINDOW *drawexit_logo() {
	WINDOW *Logo = (WINDOW *)NULL;
	int county, countx;
	Logo = newwin(24, 80, 0,0);
	for(county = 0; county < 19; county++)
		for(countx = 0; countx < 80; countx++)
			mvwaddch(Logo, county, countx, exit_logo[county][countx]);
	return Logo;
}

WINDOW *drawstart_logo() {
	WINDOW *Logo = (WINDOW *)NULL;
	int county, countx;
	Logo = newwin(24,80,0,0);
	for(county = 0; county < 23; county++)
		for(countx = 0; countx < 80; countx++) 
			mvwaddch(Logo, county, countx, tetra_logo[county][countx]);
	return Logo;
}

void drawstatus(page *curpage, int cpage) {
	int count = 0;
	move(curpage->statusbar, 0);
	printw("                                                                                ");
	move(curpage->statusbar, 0);
	attrset(A_NORMAL);
	addch('(' | m_get_colour(COLOR_CYAN, COLOR_BLACK, 0, 0));
	printw("%3d", curpage->x);
	addch(',' | m_get_colour(COLOR_CYAN, COLOR_BLACK, 0, 0));
	printw("%3d", curpage->oy + curpage->y);
	addch(')' | m_get_colour(COLOR_CYAN, COLOR_BLACK, 0, 0));
	addch(' ');
	addch(' ');
	attron(m_get_colour(curpage->fg, curpage->bg, curpage->bold,curpage->flash));
	printw("cOLOUR");
	attrset(A_NORMAL);
	attron(m_get_colour(COLOR_CYAN, COLOR_BLACK, 0, 0));
	addch(' ');
	addch('[');
	attron(m_get_colour(COLOR_GREEN, COLOR_BLACK, 0, 0));
	if (curpage->insert) 
		addch('i');
	else
		addch(' ');
	attron(m_get_colour(COLOR_CYAN, COLOR_BLACK, 0, 0));
	addch(']');
	attrset(A_NORMAL);
	addch(' ');
	attron(m_get_colour(COLOR_GREEN, COLOR_BLACK, 0, 0));
	addch('p');
	attron(m_get_colour(COLOR_CYAN, COLOR_BLACK, 0, 0));
	addch('[');
	attrset(A_NORMAL);
	attron(m_get_colour(COLOR_GREEN, COLOR_BLACK, 0, 0));
	printw("%1d", cpage);
	attron(m_get_colour(COLOR_CYAN, COLOR_BLACK, 0, 0));
	addch(']');
	attrset(A_NORMAL);
	addch(' ');
	attron(m_get_colour(COLOR_GREEN, COLOR_BLACK, 0, 0));
	addch('c');
	addch('s');
	attron(m_get_colour(COLOR_CYAN, COLOR_BLACK, 0, 0));
	addch('[');
	attrset(A_NORMAL);
	attron(m_get_colour(COLOR_GREEN, COLOR_BLACK, 0, 0));
	printw("%2d", curpage->hascii);
	attron(m_get_colour(COLOR_CYAN, COLOR_BLACK, 0, 0));
	addch(']');
	attrset(A_NORMAL);
	addch(' ');

	for(;count < 9; count++) {
		attron(m_get_colour(COLOR_YELLOW, COLOR_BLACK, 1, 0));
		printw("%1d", count + 1);
		attrset(A_NORMAL);
		addch('=');
		attron(m_get_colour(COLOR_CYAN, COLOR_BLACK, 0, 0));
		addch(tet_opts.highascii[curpage->hascii][count] | A_ALTCHARSET);
	}
	{
		attron(m_get_colour(COLOR_YELLOW, COLOR_BLACK, 1, 0));
		printw("%2d", count + 1);
		attrset(A_NORMAL);
		addch('=');
		attron(m_get_colour(COLOR_CYAN, COLOR_BLACK, 0, 0));
		addch(tet_opts.highascii[curpage->hascii][count] | A_ALTCHARSET);
	}
	attrset(A_NORMAL);
	if (remote) {
		addch('(' | m_get_colour(COLOR_CYAN, COLOR_BLACK, 0, 0));
		printw("%3d", remote->x);
		addch(',' | m_get_colour(COLOR_CYAN, COLOR_BLACK, 0, 0));
		printw("%3d", remote->oy + remote->y);
		addch(')' | m_get_colour(COLOR_CYAN, COLOR_BLACK, 0, 0));
	}
}

void drawcolours_stat(page *curpage, WINDOW *cwin) { 
	mvwaddch(cwin, 2, 12 + (curpage->fg * 2), '' | A_ALTCHARSET | m_get_colour(COLOR_MAGENTA, COLOR_BLACK, 0, 0));
	mvwaddch(cwin, 2, 13 + (curpage->fg * 2), '' | A_ALTCHARSET | m_get_colour(COLOR_MAGENTA, COLOR_BLACK, 0, 0));
	mvwaddch(cwin, 2, 48 + (curpage->bg * 2), '' | A_ALTCHARSET | m_get_colour(COLOR_MAGENTA, COLOR_BLACK, 0, 0));
	mvwaddch(cwin, 2, 49 + (curpage->bg * 2),'' | A_ALTCHARSET | m_get_colour(COLOR_MAGENTA, COLOR_BLACK, 0, 0));
	wrefresh(cwin);
}

void drawcolours(page *curpage) {
	WINDOW *cwin;
	int countx, county;
	int ch;
	cwin = newwin(8, 80, 8, 0);

	for(county = 0; county < 8;county++)
		for(countx = 0; countx < 80; countx++)
			mvwaddch(cwin, county, countx, colour_ansi[county][countx]);
	wrefresh(cwin);
	if (curpage->bold)
		curpage->fg += 8;
	drawcolours_stat(curpage, cwin);
	refresh();
	while ((ch = md_getch()) != 13) {
		switch (ch) {
			case KEY_UP:
				mvwaddch(cwin, 2, 48 + (curpage->bg * 2), ' ' | A_NORMAL);
				mvwaddch(cwin, 2, 49 + (curpage->bg * 2), ' ' | A_NORMAL);
				if (curpage->bg+1<8) curpage->bg++; else curpage->bg = 0;
				break;
			case KEY_DOWN:
				mvwaddch(cwin, 2, 48 + (curpage->bg * 2), ' ' | A_NORMAL);
				mvwaddch(cwin, 2, 49 + (curpage->bg * 2), ' ' | A_NORMAL);
				if (curpage->bg-1>=0) curpage->bg--; else curpage->bg = 7;
				break;
			case KEY_LEFT:
				mvwaddch(cwin, 2, 12 + (curpage->fg * 2), ' ' | A_NORMAL);
				mvwaddch(cwin, 2, 13 + (curpage->fg * 2), ' ' | A_NORMAL);
				if (curpage->fg-1>=0) curpage->fg--; else curpage->fg = 15;
				break;
			case KEY_RIGHT:
				mvwaddch(cwin, 2, 12 + (curpage->fg * 2), ' ' | A_NORMAL);
				mvwaddch(cwin, 2, 13 + (curpage->fg * 2), ' ' | A_NORMAL);
				if (curpage->fg+1<16) curpage->fg++; else curpage->fg = 0;
				break;
		}
		drawcolours_stat(curpage, cwin);
		refresh();
	}
	if (curpage->fg>=8) {
		curpage->bold = 1;
		curpage->fg -= 8;
	} else curpage->bold = 0; 
	delwin(cwin);
}

void grazzt(WINDOW *win, char *dirname, char *fname) {
	int count = 0, len = 0, offset = 0;
	char *string = (char *)string;

	if (!strcmp("/", dirname)) {
		string = (char *)malloc(strlen(dirname) + strlen(fname) + 1);
		sprintf(string, "%s%s", dirname, fname);
	} else {
		string = (char *)malloc(strlen(dirname) + strlen(fname) + 2);
		sprintf(string, "%s/%s", dirname, fname);
	}
	len = strlen(string);
	if (len>35) 
		offset = len - 35;
	for(count = 0;count < 35;count++) 
		mvwaddch(win, 0, count, ' ' | m_get_colour(COLOR_BLACK, COLOR_WHITE, 1, 0));
	for(count = 0;count < 35;count++) {
		if (string[count] == '\0') break;
		mvwaddch(win, 0, count, string[offset + count] | m_get_colour(COLOR_BLACK, COLOR_WHITE, 1, 0));
	}
	free(string);
	wrefresh(win);
}


void chk_sauce(WINDOW *saucewin, const char *filename, char *author, char *group, char *title) {
	char *string = (char *)NULL;
	FILE *fd = (FILE *)NULL;
	int blah = 0;

	string = (char *)malloc(128 + 1);
	fd = fopen(filename, "r");
	if (fd == NULL) {
		title[0] = '\0';
		author[0] = '\0';
		group[0] = '\0';
		return;
	}
	fseek(fd, -128, SEEK_END);
	fgets(string, 128, fd);
	fclose(fd);
	string[128] = '\0';
	if ((blah = strncmp("SAUCE", string, 5))) {
		title[0] = '\0';
		author[0] = '\0';
		group[0] = '\0';
	} else {
		memcpy(title, (string+7), 35);
		title[35] = '\0';
		memcpy(author, (string+42), 20);
		author[20] = '\0';
		memcpy(group, (string+62), 20);
		group[20] = '\0';
	}
	werase(saucewin);
	mvwprintw(saucewin, 0, 0, author);
	mvwprintw(saucewin, 1, 0, group);
	mvwprintw(saucewin, 2, 0, title);
	wrefresh(saucewin);
	free(string);
	return;
}

char *fchooser() {
	WINDOW *wfchooser = (WINDOW *)NULL;
	WINDOW *wfmenu = (WINDOW *)NULL;
	WINDOW *wgrazzt = (WINDOW *)NULL;
	WINDOW *saucewin = (WINDOW *)NULL;
	MENU *mfmenu = (MENU *)NULL;

	char **filelist = (char **)NULL;
	char dirname[1024];
	char fname[256];

	char title[36];
	char author[21];
	char group[21];

	ITEM **items = (ITEM **)NULL;
	ITEM *current = (ITEM *)NULL;

	char *filename = (char *)NULL;
	int county = 0, countx = 0, numfiles = 0, ch = 0, index = 0, offset = 0;

	struct stat sbuff;

	wfchooser = newwin(25, 80, 0, 0);
	wfmenu = newwin(14, 37, 10, 41);
	wgrazzt = newwin(1, 35, 23, 1);
	saucewin = newwin(3, 25, 19, 11); 
	wbkgdset(wfmenu, m_get_colour(COLOR_BLACK, COLOR_WHITE, 0, 0));
	wbkgdset(saucewin, m_get_colour(COLOR_BLACK, COLOR_WHITE, 0, 0));
	for(county = 0; county < 25;county++)
		for(countx = 0; countx < 80; countx++) 
			mvwaddch(wfchooser, county, countx, fchooser_ansi[county][countx]);
	mvwaddch(wfchooser, 14, 40, ' ' | m_get_colour(COLOR_BLACK, COLOR_WHITE, 0, 0));
	wattrset(saucewin, m_get_colour(COLOR_BLACK, COLOR_WHITE, 1, 0));
	werase(wfmenu);
	werase(saucewin);
	wrefresh(wfchooser);
	wrefresh(saucewin);

	fname[0] = '\0';
	while(1 == 1) {
		getcwd(dirname, 1023);
		grazzt(wgrazzt, dirname, fname);
		filelist = new_filelist(dirname, &numfiles);
		items = create_items(filelist, numfiles);
		mfmenu = new_menu(NULL);
		set_menu_win(mfmenu, wfmenu);
		set_menu_sub(mfmenu, wfmenu);
		set_menu_mark(mfmenu, NULL);
		set_menu_fore(mfmenu, m_get_colour(COLOR_WHITE, COLOR_GREEN, 1, 0));
		set_menu_back(mfmenu, m_get_colour(COLOR_WHITE, COLOR_WHITE, 1, 0));
		set_menu_items(mfmenu, items);
		set_menu_format(mfmenu, 14, 1);
		post_menu(mfmenu);
		wrefresh(wfchooser);
		wrefresh(wfmenu);
		while ((ch = md_getch()) != 13) {
			switch(ch) {
				case KEY_UP:
					menu_driver(mfmenu, REQ_UP_ITEM);
					fname[0] = '\0';
					offset = 0;
					grazzt(wgrazzt, dirname, fname);
					wrefresh(wfmenu);
					break;
				case KEY_DOWN:
					menu_driver(mfmenu, REQ_DOWN_ITEM);
					fname[0] = '\0';
					offset = 0;
					grazzt(wgrazzt, dirname, fname);
					wrefresh(wfmenu);
					break;
				case KEY_LEFT:
					menu_driver(mfmenu, REQ_LEFT_ITEM);
					fname[0] = '\0';
					offset = 0;
					grazzt(wgrazzt, dirname, fname);
					wrefresh(wfmenu);
					break;
				case KEY_RIGHT:
					menu_driver(mfmenu, REQ_RIGHT_ITEM);
					fname[0] = '\0';
					offset = 0;
					grazzt(wgrazzt, dirname, fname);
					wrefresh(wfmenu);
					break;
				case KEY_BACKSPACE:
					if (offset>0) offset--; else offset = 0;
					fname[offset] = '\0';
					break;
				case KEY_COLOUR:
					unpost_menu(mfmenu);
					free_menu(mfmenu);
					free_items(items);
					free_filelist(filelist);
					goto escape;
				default:
					if(isgraph(ch)) {
						fname[offset] = ch;
						if (offset<255) offset++; else offset = 255;
						fname[offset] = '\0';
					}
					break;
			}
			current = current_item(mfmenu);
			index = current->index;
			filename = (char *)malloc(strlen(filelist[index]) + strlen(dirname) + 2);
			sprintf(filename, "%s/%s", dirname, filelist[index]);
			chk_sauce(saucewin, filename, author, group, title);
			free(filename);
			filename = NULL;
			grazzt(wgrazzt, dirname, fname);
		}
		current = current_item(mfmenu);
		index = current->index;
		unpost_menu(mfmenu);
		free_menu(mfmenu);
		free_items(items);
		if (!strcmp("", fname)) {
			stat(filelist[index], &sbuff);
			if (!S_ISDIR(sbuff.st_mode)) {
				filename = (char *)malloc(strlen(filelist[index]) + strlen(dirname) + 2);
				sprintf(filename, "%s/%s", dirname, filelist[index]);
				free_filelist(filelist);
				delwin(wfchooser);
				delwin(wfmenu);
				delwin(wgrazzt);
				delwin(saucewin);
				return filename;
			} else { 
				chdir(filelist[index]);
				free_filelist(filelist);
			}
		} else {
				free_filelist(filelist);
				if (!strcmp("/", dirname)) {
					filename = (char *)malloc(strlen(dirname) + strlen(fname) + 1);
					sprintf(filename, "%s%s", dirname, fname);
				} else {
					filename = (char *)malloc(strlen(dirname) + strlen(fname) + 2);
					sprintf(filename, "%s/%s", dirname, fname);
				}
				delwin(wfchooser);
				delwin(wfmenu);
				delwin(wgrazzt);
				delwin(saucewin);
				return filename;
		}
	}
	escape:
	delwin(wfchooser);
	delwin(wfmenu);
	delwin(wgrazzt);
	delwin(saucewin);
	return NULL;
}

char **new_filelist(const char *dirname, int *numfiles) {
	char **filelist = (char **)NULL;
	DIR *dir = (DIR *)NULL;
	struct dirent *dire = (struct dirent *)NULL;
	int count = 0;

	*numfiles = 0;
	dir = opendir(dirname);
	while((dire = readdir(dir))) *numfiles += 1;
	rewinddir(dir);
	filelist = calloc(*numfiles + 1, sizeof(char *));
	while((dire = readdir(dir))) {
		if ((dire->d_name[0] == '.' && dire->d_name[1] != '.')&&strcmp(dire->d_name, ".tetradraw-autosave.ans")) continue;
		if ((!strcmp(dire->d_name, "..")&&!strcmp(dirname, "/"))) continue;
		filelist[count] = malloc(strlen(dire->d_name) + 1);
		strcpy(filelist[count], dire->d_name);
		count++;
	}
	filelist[count] = NULL;
	closedir(dir);
	return filelist;
}

ITEM **create_items(char **filelist, int numfiles) {
	ITEM **items = (ITEM **)NULL;
	int count = 0;
	items = calloc(numfiles + 1, sizeof(ITEM *));
	for(; filelist[count] != NULL;count++) 
		items[count] = new_item(filelist[count], NULL);
	items[count] = NULL;
	return items;
}

int free_items(ITEM **items) {
	int count = 0;
	for(; items[count] != NULL;count++) 
		free_item(items[count]);
	free(items);
	items = NULL;
	return 0;
}

int free_filelist(char **filelist) {
	int count = 0;
	for(; filelist[count] != NULL;count++)
		free(filelist[count]);
	free(filelist);
	filelist = NULL;
	return 0;
}

void select_f_fg(int *fg) {
	int countx, county;
	int ch;
	int done = 0;
	char fgbuff[2];
	int foffset = 0;
	WINDOW *clrwin = (WINDOW *)NULL;
	clrwin = newwin(25, 80, 0, 0);
	for(county = 0; county < 25; county++)
		for(countx = 0; countx < 80; countx++)
			mvwaddch(clrwin, county, countx, select_fg[county][countx]);

	fgbuff[0] = fgbuff[1] = ' ';
	mvwaddch(clrwin, 17, 69, 'c' | m_get_colour(COLOR_GREEN, COLOR_BLACK, 0, 0));
	mvwaddch(clrwin, 17, 70, 'l' | m_get_colour(COLOR_GREEN, COLOR_BLACK, 0, 0));
	mvwaddch(clrwin, 17, 71, 'r' | m_get_colour(COLOR_GREEN, COLOR_BLACK, 0, 0));
	mvwaddch(clrwin, 17, 73, ' ' | m_get_colour(COLOR_BLACK, COLOR_YELLOW, 0, 0));
	mvwaddch(clrwin, 17, 74, ' ' | m_get_colour(COLOR_BLACK, COLOR_YELLOW, 0, 0));
	wmove(clrwin, 17, 73 + foffset);
	wrefresh(clrwin);

	while (!done&&(ch = md_getch(remote))) {
		switch (ch) {
			case KEY_COLOUR:
				*fg = -1;
				done = 1;
				break;
			case 13:
				if (isdigit(fgbuff[0]) || isdigit(fgbuff[1])) {
					if (isdigit(fgbuff[1])) {
						*fg = (fgbuff[0] - '0') * 10;
						*fg += (fgbuff[1] - '0');
					} else *fg = fgbuff[0] - '0';
					if (*fg > 31 || *fg < 0) 
						*fg = -1;
					done = 1;
				}
				break;
			case KEY_BACKSPACE:
				fgbuff[foffset] = ' ';
				if (foffset-1>=0) foffset--;
				break;
			default:
				if (isdigit(ch)) {
					fgbuff[foffset] = ch;
					if (foffset+1<2) foffset++;
				}
				break;
		}
		mvwaddch(clrwin, 17, 73, fgbuff[0] | m_get_colour(COLOR_BLACK, COLOR_YELLOW, 0, 0));
		mvwaddch(clrwin, 17, 74, fgbuff[1] | m_get_colour(COLOR_BLACK, COLOR_YELLOW, 0, 0));
		wmove(clrwin, 17, 73 + foffset);
		wrefresh(clrwin);
	}
	delwin(clrwin);
}
	
void select_f_bg(int *bg) {
	int countx, county;
	int ch;
	int done = 0;
	char bgbuff[2];
	int boffset = 0;
	WINDOW *clrwin = (WINDOW *)NULL;
	clrwin = newwin(25, 80, 0, 0);
	for(county = 0; county < 25; county++)
		for(countx = 0; countx < 80; countx++)
			mvwaddch(clrwin, county, countx, select_bg[county][countx]);

	mvwaddch(clrwin, 17, 69, 'c' | m_get_colour(COLOR_GREEN, COLOR_BLACK, 0, 0));
	mvwaddch(clrwin, 17, 70, 'l' | m_get_colour(COLOR_GREEN, COLOR_BLACK, 0, 0));
	mvwaddch(clrwin, 17, 71, 'r' | m_get_colour(COLOR_GREEN, COLOR_BLACK, 0, 0));
	mvwaddch(clrwin, 17, 73, ' ' | m_get_colour(COLOR_BLACK, COLOR_YELLOW, 0, 0));
	mvwaddch(clrwin, 17, 74, ' ' | m_get_colour(COLOR_BLACK, COLOR_YELLOW, 0, 0));
	wmove(clrwin, 17, 73 + boffset);
	wrefresh(clrwin);

	bgbuff[0] = bgbuff[1] = ' ';
	while (!done&&(ch = md_getch(remote))) {
		switch (ch) {
			case KEY_COLOUR:
				*bg = -1;
				done = 1;
				break;
			case 13:
				if (isdigit(bgbuff[0])) {
					*bg = bgbuff[0] - '0';
					if (*bg > 7 || *bg < 0) 
						*bg = -1;
					done = 1;
				}
				break;
			case KEY_BACKSPACE:
				bgbuff[boffset] = ' ';
				break;
			default:
				if (isdigit(ch)) {
					bgbuff[boffset] = ch;
				}
				break;
		}
		mvwaddch(clrwin, 17, 73, bgbuff[0] | m_get_colour(COLOR_BLACK, COLOR_YELLOW, 0, 0));
		mvwaddch(clrwin, 17, 74, bgbuff[1] | m_get_colour(COLOR_BLACK, COLOR_YELLOW, 0, 0));
		wmove(clrwin, 17, 73 + boffset);
		wrefresh(clrwin);
	}
	delwin(clrwin);
}

void select_f_char(int *ch) {
	*ch = -1;
}

void select_r_fg(int *fg1, int *fg2) {
	select_f_fg(fg1);
	select_f_fg(fg2);
}

void select_r_bg(int *bg1, int *bg2) {
	select_f_bg(bg1);
	select_f_bg(bg2);
}

void select_r_char(int *ch1, int *ch2) {
	*ch1 = *ch2 = -1;
}

void draw_chat(WINDOW *md_win) {
	int count = 0;
	for(count = 0; count < 8; count++)
		mvwhline(md_win, 8 + count, 3, ' ', 75);
	for(count = 0; count < 8; count++)
		if (remote->chat[count] == NULL) break;
		else mvwprintw(md_win, 8 + count, 3, "%s", remote->chat[count]);
		
}

void md_move(WINDOW *md_win, int server, int ilev, int hcount, int ncount, int pcount) {
	if (server) {
		switch (ilev) {
			case 0:
				wmove(md_win, 1, 16);
				break;
			case 1:
				wmove(md_win, 3, 13 + pcount);
				break;
			case 2:
				wmove(md_win, 4, 13 + ncount);
				break;
			case 3:
				wmove(md_win, 5, 13);
				break;
		}
	} else {
		switch (ilev) {
			case 0:
				wmove(md_win, 1, 16);
				break;
			case 1:
				break;
			case 2:
				wmove(md_win, 3, 13 + pcount);
				break;
			case 3:
				wmove(md_win, 4, 13 + ncount);
				break;
			case 4:
				wmove(md_win, 5, 13);
				break;
		}
	}
}

void draw_info(WINDOW *md_win, int server, char *handle, char *hostname, char *port) {
	int offset = 0;
	int len = strlen(hostname);
	if (len > 23)
		offset = len - 23;
	mvwprintw(md_win, 3, 13, "      ");
	mvwprintw(md_win, 3, 13, "%s", port);
	mvwprintw(md_win, 4, 13, "           ");
	mvwprintw(md_win, 4, 13, "%s", handle);
	mvwprintw(md_win, 2, 13, "                       ");
	mvwprintw(md_win, 2, 13, "%s", (hostname+offset));
}

/* ilev for client
 * 0 -- left and right for server / client
 * 1 -- type in ip / hostname
 * 2 -- type in port
 * 3 -- type in handle
 * 4 -- press enter to connect
 */
/* return codes for client input
 * -1 -- something went wrong during connect
 * 		display error in status bar and continue taking input again
 * -2 -- user abort 
 * 		quit multidraw all together
 * -3 -- user switched from client to server mode
 *      switch input cycles
 */

int client_input(WINDOW *md_win, int *server, char *handle, char *hostname, char *port) {
	int ilev = 0;
	int ch = 0;
	int ncount = 0, hcount = 0, pcount = 0;
	int done = 0;
	int prt = 0;

	handle[ncount] = hostname[hcount] = port[pcount] = '\0';
	mvwprintw(md_win, 5, 13, "  CONNECT  ");
	mvwprintw(md_win, 1, 16, "      ");
	wattrset(md_win, m_get_colour(COLOR_GREEN, COLOR_YELLOW, 0, 0));
	mvwprintw(md_win, 1, 16, "  NO  ");
	wattrset(md_win, A_NORMAL);
	draw_info(md_win, *server, handle, hostname, port);
	md_move(md_win, *server, ilev, hcount, ncount, pcount);
	wrefresh(md_win);
	while (!done&&(ch = md_getch())) {
		switch (ch) {
			case -1:
				break;
			case KEY_COLOUR:
				done = 1;
				return -2;
				break;
			case 13:
				if (ilev == 4) {
					prt = atoi(port);
					remote->localhandle = strdup(handle);
					remote->sock = remote_connect(hostname, prt);
					if (remote->sock <= 0) {
						if (remote->sock == -3) {
							mvwhline(md_win, 5, 36, ' ', 80 - 36);
							mvwprintw(md_win, 5, 36, "Error: could not look up hostname");
						}
						if (remote->sock == -2) {
							mvwhline(md_win, 5, 36, ' ', 80 - 36);
							mvwprintw(md_win, 5, 36, "Error: could not create socket");
						}
						if (remote->sock == -1) {
							mvwhline(md_win, 5, 36, ' ', 80 - 36);
							mvwprintw(md_win, 5, 36, "Error: connection refused");
						}
						return -1;
					}
					md_sendcmd(CMD_HELO, remote->localhandle);
					return 0;
				}
				break;
			case KEY_UP: 
				ilev--;
				if (ilev<0) ilev = 0;
				break;
			case KEY_DOWN:
				ilev++;
				if (ilev>4) ilev = 4;
				break;
			case KEY_LEFT:
				if (ilev == 0) { 
					*server = 1;
					return -3;
				}
				break;
			case KEY_RIGHT:
				if (ilev == 0) *server = 0;
				break;
			case KEY_BACKSPACE:
				if (ilev == 1) {
					hcount--;
					if (hcount < 0) hcount = 0;
					hostname[hcount] = '\0';
					break;
				}
				if (ilev == 2) {
					pcount--;
					if (pcount < 0) pcount = 0;
					port[pcount] = '\0';
					break;
				}
				if (ilev == 3) {
					ncount--;
					if (ncount < 0) ncount = 0;
					handle[ncount] = '\0';
					break;
				}
				break;
			default:
				if (isprint(ch))  {
					if (ilev == 1) {
						hostname[hcount] = ch;
						hcount++;
						if (hcount > 1023) hcount = 1023;
						hostname[hcount] = '\0';
						break;
					}
					if (ilev == 2) {
						port[pcount] = ch;
						pcount++;
						if (pcount > 5) pcount = 5;
						port[pcount] = '\0';
						break;
					}
					if (ilev == 3) {
						handle[ncount] = ch;
						ncount++;
						if (ncount > 9) ncount = 9;
						handle[ncount] = '\0';
						break;
					}
				}
				break;
		}
		if (ilev == 4)  {
			wattrset(md_win, m_get_colour(COLOR_GREEN, COLOR_YELLOW, 0, 0));
			mvwprintw(md_win, 5, 13, "  CONNECT  ");
			wattrset(md_win, A_NORMAL);
		} else {
			mvwprintw(md_win, 5, 13, "  CONNECT  ");
		}
		if (ilev == 0) { 
			mvwprintw(md_win, 1, 16, "      ");
			wattrset(md_win, m_get_colour(COLOR_GREEN, COLOR_YELLOW, 0, 0));
			mvwprintw(md_win, 1, 16, "  NO  ");
			wattrset(md_win, A_NORMAL);
		} else {
			mvwprintw(md_win, 1, 16, "      ");
			mvwprintw(md_win, 1, 16, "  NO  ");
		}
		draw_info(md_win, *server, handle, hostname, port);
		md_move(md_win, *server, ilev, hcount, ncount, pcount);
		wrefresh(md_win);
	}
	return 0;
}

/* ilev for server
 * 0 -- left and right for server / client
 * 1 -- type in  port
 * 2 -- type in handle
 * 3 -- press return to wait for connection
 */
/* return codes for server input
 * -1 -- something went wrong during connect
 *       draw error on status bar and keep taking input
 * -2 -- user abort
 *       quit multidraw
 * -3 -- user switched from server to client
 *       switch from taking server_input to client_input
 */

int server_input(WINDOW *md_win, int *server, char *handle, 
		char *hostname, char *port) {
	int ilev = 0;
	int ch = 0;
	int ncount = 0, hcount = 0, pcount = 0;
	int done = 0;
	int prt = 0;
	port[pcount] = handle[ncount] = hostname[hcount] = '\0';

	mvwprintw(md_win, 5, 13, "  CONNECT  ");
	mvwprintw(md_win, 1, 16, "      ");
	wattrset(md_win, m_get_colour(COLOR_GREEN, COLOR_YELLOW, 0, 0));
	mvwprintw(md_win, 1, 16, "  YES ");
	wattrset(md_win, A_NORMAL);
	draw_info(md_win, *server, handle, hostname, port);
	md_move(md_win, *server, ilev, hcount, ncount, pcount);
	wrefresh(md_win);
	while (!done&&(ch = md_getch())) {
		switch (ch) {
			case -1:
				break;
			case 13:
				if (ilev == 3) {
					prt = atoi(port);
					remote->localhandle = strdup(handle);
					remote->sock = remote_connect_server(prt);
					if (remote->sock <= 0) {
						if (remote->sock == -3) {
							mvwhline(md_win, 5, 36, ' ', 80 - 36);
							mvwprintw(md_win, 5, 36, "Error: could not bind to port");
						}
						if (remote->sock == -2) {
							mvwhline(md_win, 5, 36, ' ', 80 - 36);
							mvwprintw(md_win, 5, 36, "Error: could not wait for connection");
						}
						if (remote->sock == -1) {
							mvwprintw(md_win, 4, 36, "Error: could not accept connection");
						}
						return -1;
					}
					md_sendcmd(CMD_HELO, remote->localhandle);
					return 0;
				}
				break;
			case KEY_COLOUR:
				return -2;
				break;
			case KEY_UP:
				ilev--;
				if (ilev < 0) ilev = 0;
				break;
			case KEY_DOWN:
				ilev++;
				if (ilev > 3) ilev = 3;
				break;
			case KEY_LEFT:
				if (ilev == 0) *server = 1;
				break;
			case KEY_RIGHT:
				if (ilev == 0) {
					*server = 0;
					return -3;
				}
				break;
			case KEY_BACKSPACE:
				if (ilev == 1) {
					pcount--;
					if (pcount < 0) pcount = 0;
					port[pcount] = '\0';
					break;
				}
				if (ilev == 2) {
					ncount--;
					if (ncount < 0) ncount = 0;
					handle[ncount] = '\0';
					break;
				}
			default:
				if (isprint(ch)) {
					if (ilev == 1) {
						port[pcount] = ch;
						pcount++;
						if (pcount > 5) pcount = 5;
						port[pcount] = '\0';
						break;
					}
					if (ilev == 2) {
						handle[ncount] = ch;
						ncount++;
						if (ncount > 9) ncount = 9;
						handle[ncount] = '\0';
						break;
					}
				}
				break;
		}
		if (ilev == 3)  {
			wattrset(md_win, m_get_colour(COLOR_GREEN, COLOR_YELLOW, 0, 0));
			mvwprintw(md_win, 5, 13, "  CONNECT  ");
			wattrset(md_win, A_NORMAL);
		} else {
			mvwprintw(md_win, 5, 13, "  CONNECT  ");
		}
		if (ilev == 0) { 
			mvwprintw(md_win, 1, 16, "      ");
			wattrset(md_win, m_get_colour(COLOR_GREEN, COLOR_YELLOW, 0, 0));
			mvwprintw(md_win, 1, 16, "  YES ");
			wattrset(md_win, A_NORMAL);
		} else {
			mvwprintw(md_win, 1, 16, "      ");
			mvwprintw(md_win, 1, 16, "  YES ");
		}
		draw_info(md_win, *server, handle, hostname, port);
		md_move(md_win, *server, ilev, hcount, ncount, pcount);
		wrefresh(md_win);
	}
	return 0;
}

/* return values
 * 0 normal
 * -1 "/disconnect"
 * -2 -- user wants to exit multidraw screen
 */

int chat_input(WINDOW *md_win, char *msg) {
	int ch = 0;
	int done = 0;
	int mcount = 0;
	int len = 0;
	int offset = 0;
	int os = strlen(remote->localhandle) + 3;

	msg[mcount] = '\0';
	mvwhline(md_win, 5, 36, ' ', 80 - 36);
	draw_chat(md_win);
	mvwprintw(md_win, 5, 36, "connected with: %s", remote->remotehandle);
	mvwhline(md_win, 23, 0, ' ', 80);
	mvwprintw(md_win, 23, 0, "<%s> %s", remote->localhandle, msg+offset);
	wrefresh(md_win);
	while (!done&&(ch = md_getch())) {
		switch (ch) {
			case -1:
				if (remote) {
					len = strlen(msg);
					if (len > (80 - os)) 
						offset = len - (80 - os);
					else offset = 0;
					draw_chat(md_win);
					mvwhline(md_win, 5, 36, ' ', 80 - 36);
					mvwprintw(md_win, 5, 36, "connected with: %s", remote->remotehandle);
					mvwhline(md_win, 23, 0, ' ', 80);
					mvwprintw(md_win, 23, 0, "<%s> %s", remote->localhandle, msg);
					wrefresh(md_win);
				} else return -1;
				break;
			case KEY_COLOUR:
				return -2;
			case KEY_BACKSPACE:
				mcount--;
				if (mcount < 0) mcount = 0;
				msg[mcount] = '\0';
				break;
			case 13:
				if (!strcasecmp(msg, "/disconnect")) {
					close(remote->sock);
					remote_destroy();
					return -1;
				} 
				md_sendcmd(CMD_TALK, msg);
				mcount = 0;
				msg[mcount] = '\0';
				break;
			default:
				if (isprint(ch)) {
					msg[mcount] = ch;
					mcount++;
					if (mcount > 1023) mcount = 1023;
					msg[mcount] = '\0';
					break;
				}
		}
		len = strlen(msg);
		if (len > (79 - os)) 
			offset = len - (79 - os);
		else offset = 0;
		draw_chat(md_win);
		mvwhline(md_win, 5, 36, ' ', 80 - 36);
		mvwprintw(md_win, 5, 36, "connected with: %s", remote->remotehandle);
		mvwhline(md_win, 23, 0, ' ', 80);
		mvwprintw(md_win, 23, 0, "<%s> %s", remote->localhandle, msg+offset);
		wrefresh(md_win);
	}
	return 0;
}

void multidraw_screen(page *curpage) {
	char handle[11];
	char hostname[1024];
	char port[7];
	char msg[1024];
	int countx, county;
	int server = 1;
	int done = 0;
	int code = 0;
	WINDOW *md_win =  (WINDOW *)NULL;
	char *m = (char *)NULL;

	md_win = newwin(25, 80, 0, 0);

	handle[0] = hostname[0] = port[0] = '\0';
	werase(md_win);
	for(county = 0; county < 12; county++)
		for(countx = 0; countx < 80; countx++) 
			mvwaddch(md_win, county, countx, multi_ansi[county][countx]);
	wrefresh(md_win);

	if(remote == NULL) {
		remote_create(curpage);
		while (!done) {
			if (server) {
				code = server_input(md_win, &server, handle, hostname, port);
				if (code == -2) {
					remote_destroy();
					delwin(md_win);
					return;
				}
				if (code == 0) {
					done = 1;
					m = (char *)malloc(1024);
					sprintf(m, "%d,%d,%d", curpage->x, curpage->oy, curpage->y);
					md_sendcmd(CMD_POS, m);
					free(m);
					m = NULL;
				}
			}
			else {
				code = client_input(md_win, &server, handle, hostname, port);
				if (code == -2) {
					remote_destroy();
					delwin(md_win);
					return;
				}
				if (code == 0) {
					done = 1;
					m = (char *)malloc(1024);
					sprintf(m, "%d,%d,%d", curpage->x, curpage->oy, curpage->y);
					md_sendcmd(CMD_POS, m);
					free(m);
					m = NULL;
				}
			}
		}
	}
	done = 0;
	code = 0;
	if (remote) {
		code = chat_input(md_win, msg);
		if (code < 0) {
			delwin(md_win);
			return;
		}
	}
}
