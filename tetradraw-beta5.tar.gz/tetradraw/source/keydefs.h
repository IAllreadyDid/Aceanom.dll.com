#ifndef __KEYDEFS_H_
#define __KEYDEFS_H_

#define KEY_DEL 330
#define KEY_INSERT 331
#define KEY_PAGEUP 339
#define KEY_PAGEDOWN 338

#define KEY_ALT_1 701
#define KEY_ALT_2 702
#define KEY_ALT_3 703
#define KEY_ALT_4 704
#define KEY_ALT_5 705
#define KEY_ALT_6 706
#define KEY_ALT_7 707
#define KEY_ALT_8 708
#define KEY_ALT_9 709
#define KEY_ALT_0 710
#define KEY_ALT_10 711
#define KEY_ALT_11 712
#define KEY_ALT_12 713
#define KEY_ALT_13 714
#define KEY_ALT_14 715
#define KEY_ALT_15 716
#define KEY_ALT_16 717
#define KEY_ALT_17 718
#define KEY_ALT_18 719
#define KEY_ALT_19 720
#define KEY_ALT_20 721

#define KEY_QUIT 722
#define KEY_LOAD 723
#define KEY_ASAVE 724
#define KEY_COLOUR 725
#define KEY_BLOCK 726

#define KEY_NEXT_PAGE 728
#define KEY_PREV_PAGE 729
#define KEY_NEW_PAGE 730
#define KEY_KILL_PAGE 731

#define KEY_SWITCH_SB 732

#define KEY_MULTIDRAW 733

#define KEY_FLASH 734

#define KEY_DELLINE 735
#define KEY_INSLINE 736

#define KEY_VDELLINE 737
#define KEY_VINSLINE 738

#endif
