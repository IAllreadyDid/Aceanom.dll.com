#ifndef __GLOBAL_H_
#define __GLOBAL_H_
#include "editor.h"
#include "multidraw.h"

extern int colours[8][8];
extern int cpage, tpage;
extern options tet_opts;
extern multid *remote;
page *pages[10];

#endif
