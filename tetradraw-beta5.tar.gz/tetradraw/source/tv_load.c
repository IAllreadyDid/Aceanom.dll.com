/*
 * tv_load.c by ttb (John McCutchan)
 *
 * tetraview file load functions
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#include "editor.h"
#include "func.h"

#define SNORMAL 0
#define SESCAPE 1
#define SGPARAM 2
#define SACTION 3

page *load_ansi(const char *);

page *load_ansi(const char *filename) {
	FILE *fd = (FILE *)NULL;
	int aa, c, state, param, count;
	int params[8] = {0,0,0,0,0,0,0};
	page *temppage = (page *)NULL;

	aa = c = param = 0;

	temppage = page_factory(temppage, PAGE_RESURRECT);
	temppage->bg = temppage->bold = temppage->flash = 0;
	temppage->fg = 7;
	fd = (FILE *)NULL;


	state = SNORMAL;
	fd = fopen(filename, "r");
	while(((c = getc(fd)) != -1) && (c != 26) ) {
		if (c >= 1 && state == SNORMAL && c <= 6) {
			char_add_l(temppage, c);
			continue;
		}
		if (c >= 16 && state == SNORMAL && c <=23) {
			char_add_l(temppage, c);
			continue;
		}
		if ((c == 25 || c == 28 || c == 29 || c == 30 || c == 31) && state == SNORMAL) {
			char_add_l(temppage, c);
			continue;
		}
		if (c >= 32 && state == SNORMAL && c < 256) {
			char_add_l(temppage, c);
			continue;
		} 
		if (c == 27 && state == SNORMAL) {
			for(count = 0;count < 8;count++)
				params[count] = 0;
			param = 0;
			state = SESCAPE;
			continue;
		} 
		if (c == '\n') {
			move_down(temppage, 1);
			move_left(temppage, 79);
			state = SNORMAL;
			continue;
		}
		switch (state) {
			case SESCAPE:
				if (c == '[') 
					continue;
				if (c >= 48 && c <= 57) {
					param = 0;
					for(aa = 0;aa < 8;aa++) 
						params[aa] = 0;
					params[param] = c-'0';
					state = SGPARAM;
					continue;
				}
			case SGPARAM:
				if (c == ';') {
					if (param<8) param++;
					continue;
				}
				if (c >= 48 && c <= 57) {
					params[param] *= 10;
					params[param] += c-'0';
					continue;
				}
			case SACTION:
				switch (c) {
					case '?':
						state = SGPARAM;
						continue;
					case 'h':
						break;
					case 'K':
						line_delete(temppage, 1);
						line_insert(temppage, 1);
						state = SNORMAL;
						break;
					case 'J':
						if (params[aa]==2) 
							page_factory(temppage, PAGE_REPACKAGE);
						state = SNORMAL;
						break;
					case 'm':
					for(aa = 0;aa <= param;aa++)
						switch (params[aa]) {
							case 0:
								temppage->fg = 7;
								temppage->bg = temppage->bold = temppage->flash = 0;
								break;
							case 1:
								temppage->bold = 1;
								break;
							case 5:
								temppage->flash = 1;
								break;
							default:
								if (params[aa] >= 30 && params[aa] <= 37)
									temppage->fg = params[aa]-30;
								else if (params[aa] >= 40 && params[aa] <= 47) 
									temppage->bg = params[aa]-40;
								break;
						}
					state = SNORMAL;
					break;
					case 'A':
						if (params[0]==0) 
							move_up(temppage, 1);
						else move_up(temppage, params[0]);
						state = SNORMAL;
						break;
					case 'B':
						if (params[0]==0)
							move_down(temppage, 1);
						else move_down(temppage, params[0]);
						state = SNORMAL;
						break;
					case 'C':
					/* forward */
						if (params[0] == 0)
							move_right(temppage, 1);
						else move_right(temppage, params[0]);
						state = SNORMAL;
						break;
					case 'D':
					/* backwards */
						if (params[0]== 0)
							move_left(temppage, 1);
						else move_left(temppage, params[0]);
						state = SNORMAL;
						break;
				}
				state = SNORMAL;
				break;
		}
	}
	temppage->x = 0;
	temppage->oy = 0;
	temppage->y = 0;
	temppage->flash = 0;
	temppage->fg = 7;
	temppage->bg = 0;
	temppage->bold = 0;
	fclose(fd);
	return temppage;
}
