/*
 * save.c by ttb (John McCutchan)
 *
 * tetradraw file save functions
 */

#include <stdio.h>
#include <stdlib.h>
#include <ncurses.h>
#include <ctype.h>
#include <time.h>

#include "global.h"
#include "editor.h"
#include "sauce.h"
#include "func.h"
#include "keydefs.h"

void savefile(page *);

int save_sauce(SAUCE *, const char *);
int save_ansi(page *, const char *);
int save_ascii(page *, const char *);

int save_c(page *,const char *);

void savefile(page *curpage) {
	char *filename = (char *)NULL;
	int done = 0;
	int count;
	int tcount;
	int ch;
	char title[35];
	char backup[35];
	int sauce_switch = 1;
	SAUCE saucy;
	filename = fchooser();

	if (filename == NULL) {
		drawstatus(curpage, 32);
		return;
	}

	drawstatus(curpage, 32);
	update(curpage);
	refresh();
	wrefresh(curpage->EditWin);

	if (!strcmp(tet_opts.save_default, "ansi")) {
		save_ansi(curpage, filename);
		saucy.filetype = 1;
	}
	else if (!strcmp(tet_opts.save_default, "ascii")) {
		save_ascii(curpage, filename);
		saucy.filetype = 0;
	} else if (!strcmp(tet_opts.save_default, "c")) {
		save_c(curpage, filename);
		return;
	}
	else {
		attrset(A_NORMAL);
		mvwprintw(stdscr, 0, 0, "                                                                                ");
		mvwaddch(stdscr, 0, 0, '(' | m_get_colour(COLOR_CYAN, COLOR_BLACK, 0, 0));
		mvwprintw(stdscr, 0, 1, "save type");
		mvwaddch(stdscr, 0, 10, ')' | m_get_colour(COLOR_CYAN, COLOR_BLACK, 0, 0));
		mvwaddch(stdscr, 0, 12, 'a' | m_get_colour(COLOR_CYAN, COLOR_BLACK, 0, 0));
		mvwprintw(stdscr, 0, 13, "nsi a");
		mvwaddch(stdscr, 0, 18, 's' | m_get_colour(COLOR_CYAN, COLOR_BLACK, 0, 0));
		mvwprintw(stdscr, 0, 19, "cii");
		refresh();
		while (!done) {
			switch (md_getch()) {
				case 'a':
				case 'A': done = 1;save_ansi(curpage, filename); saucy.filetype = 1;break;
				case 's':
				case 'S': done = 1;save_ascii(curpage, filename); saucy.filetype = 0;break;
				case KEY_COLOUR: done = 1;
			}
		}
	}
	attrset(A_NORMAL);
	mvwprintw(stdscr, 0, 0, "                                                                                ");
	mvwaddch(stdscr, 0, 0, '(' | m_get_colour(COLOR_CYAN, COLOR_BLACK, 0, 0));
	mvwprintw(stdscr, 0, 1, "clear screen");
	mvwaddch(stdscr, 0, 13, ')' | m_get_colour(COLOR_CYAN, COLOR_BLACK, 0, 0));
	mvwaddch(stdscr, 0, 15, 'y' | m_get_colour(COLOR_CYAN, COLOR_BLACK, 0, 0));
	mvwprintw(stdscr, 0, 16, "es");
	mvwaddch(stdscr, 0, 19, 'n' | m_get_colour(COLOR_CYAN, COLOR_BLACK, 0, 0));
	mvwprintw(stdscr, 0, 20, "o");
	done = 0;
	while (!done) {
		done = 1;
	}
	if (!strcmp(tet_opts.save_sauce, "ask")) {
		attrset(A_NORMAL);
		mvwprintw(stdscr, 0, 0, "                                                                                ");
		mvwaddch(stdscr, 0, 0, '(' | m_get_colour(COLOR_CYAN, COLOR_BLACK, 0, 0));
		mvwprintw(stdscr, 0, 1, "save sauce");
		mvwaddch(stdscr, 0, 11, ')' | m_get_colour(COLOR_CYAN, COLOR_BLACK, 0, 0));
		mvwaddch(stdscr, 0, 13, ' ' | m_get_colour(COLOR_GREEN, COLOR_YELLOW, 0, 0));
		mvwaddch(stdscr, 0, 14, 'Y' | m_get_colour(COLOR_GREEN, COLOR_YELLOW, 0, 0));
		mvwaddch(stdscr, 0, 15, 'E' | m_get_colour(COLOR_GREEN, COLOR_YELLOW, 0, 0));
		mvwaddch(stdscr, 0, 16, 'S' | m_get_colour(COLOR_GREEN, COLOR_YELLOW, 0, 0));
		mvwaddch(stdscr, 0, 17, ' ' | m_get_colour(COLOR_GREEN, COLOR_YELLOW, 0, 0));
		mvwaddch(stdscr, 0, 18, ' ' | m_get_colour(COLOR_GREEN, COLOR_BLACK, 0, 0));
		mvwaddch(stdscr, 0, 19, 'N' | m_get_colour(COLOR_GREEN, COLOR_BLACK, 0, 0));
		mvwaddch(stdscr, 0, 20, 'O' | m_get_colour(COLOR_GREEN, COLOR_BLACK, 0, 0));
		mvwaddch(stdscr, 0, 21, ' ' | m_get_colour(COLOR_GREEN, COLOR_BLACK, 0, 0));
		while (!done) {
			switch ((ch = md_getch())) {
				case KEY_LEFT: 
					sauce_switch = 1;
					break;
				case KEY_RIGHT: 
					sauce_switch = 0;
					break;
				case 'y':
				case 'Y': goto save_sauce; break;
				case 'n':
				case 'N': break;
				case 13:
				  if (sauce_switch) goto save_sauce;
				  else done = 1; break;
			}
			if (sauce_switch) {
				mvwprintw(stdscr, 0, 0, "                                                                                ");
				mvwaddch(stdscr, 0, 0, '(' | m_get_colour(COLOR_CYAN, COLOR_BLACK, 0, 0));
				mvwprintw(stdscr, 0, 1, "save sauce");
				mvwaddch(stdscr, 0, 11, ')' | m_get_colour(COLOR_CYAN, COLOR_BLACK, 0, 0));
				mvwaddch(stdscr, 0, 13, ' ' | m_get_colour(COLOR_GREEN, COLOR_YELLOW, 0, 0));
				mvwaddch(stdscr, 0, 14, 'Y' | m_get_colour(COLOR_GREEN, COLOR_YELLOW, 0, 0));
				mvwaddch(stdscr, 0, 15, 'E' | m_get_colour(COLOR_GREEN, COLOR_YELLOW, 0, 0));
				mvwaddch(stdscr, 0, 16, 'S' | m_get_colour(COLOR_GREEN, COLOR_YELLOW, 0, 0));
				mvwaddch(stdscr, 0, 17, ' ' | m_get_colour(COLOR_GREEN, COLOR_YELLOW, 0, 0));
				mvwaddch(stdscr, 0, 18, ' ' | m_get_colour(COLOR_GREEN, COLOR_BLACK, 0, 0));
				mvwaddch(stdscr, 0, 19, 'N' | m_get_colour(COLOR_GREEN, COLOR_YELLOW, 0, 0));
				mvwaddch(stdscr, 0, 20, 'O' | m_get_colour(COLOR_GREEN, COLOR_BLACK, 0, 0));
				mvwaddch(stdscr, 0, 21, ' ' | m_get_colour(COLOR_GREEN, COLOR_BLACK, 0, 0));
			} else {
				mvwprintw(stdscr, 0, 0, "                                                                                ");
				mvwaddch(stdscr, 0, 0, '(' | m_get_colour(COLOR_CYAN, COLOR_BLACK, 0, 0));
				mvwprintw(stdscr, 0, 1, "save sauce");
				mvwaddch(stdscr, 0, 11, ')' | m_get_colour(COLOR_CYAN, COLOR_BLACK, 0, 0));
				mvwaddch(stdscr, 0, 13, ' ' | m_get_colour(COLOR_GREEN, COLOR_BLACK, 0, 0));
				mvwaddch(stdscr, 0, 14, 'Y' | m_get_colour(COLOR_GREEN, COLOR_BLACK, 0, 0));
				mvwaddch(stdscr, 0, 15, 'E' | m_get_colour(COLOR_GREEN, COLOR_BLACK, 0, 0));
				mvwaddch(stdscr, 0, 16, 'S' | m_get_colour(COLOR_GREEN, COLOR_BLACK, 0, 0));
				mvwaddch(stdscr, 0, 17, ' ' | m_get_colour(COLOR_GREEN, COLOR_BLACK, 0, 0));
				mvwaddch(stdscr, 0, 18, ' ' | m_get_colour(COLOR_GREEN, COLOR_YELLOW, 0, 0));
				mvwaddch(stdscr, 0, 19, 'N' | m_get_colour(COLOR_GREEN, COLOR_YELLOW, 0, 0));
				mvwaddch(stdscr, 0, 20, 'O' | m_get_colour(COLOR_GREEN, COLOR_YELLOW, 0, 0));
				mvwaddch(stdscr, 0, 21, ' ' | m_get_colour(COLOR_GREEN, COLOR_YELLOW, 0, 0));
			}
		}
	} else if (!strcmp(tet_opts.save_sauce, "yes")) {
		save_sauce:
		attrset(A_NORMAL);
		mvwprintw(stdscr, 0, 0, "                                                                                ");
		mvwaddch(stdscr, 0, 0, '(' | m_get_colour(COLOR_CYAN, COLOR_BLACK, 0, 0));
		mvwprintw(stdscr, 0, 1, "title");
		mvwaddch(stdscr, 0, 6, ')' | m_get_colour(COLOR_CYAN, COLOR_BLACK, 0, 0));
		for(count = 0; count < 35; count++) 
			backup[count] = title[count] = tet_opts.sauce_title[count];
		for(count = 0; count < 35; count++) 
			mvwaddch(stdscr, 0, 8 + count, title[count]);
		refresh();
		tcount = 0;
		done = 0;
		move(0, tcount + 8);
		while (!done) {
			switch ((ch = md_getch())) {
				case 13: done = 1; break;
				case KEY_LEFT: if (tcount-1 >= 0) tcount--; else tcount = 0;
							break;
				case KEY_RIGHT: if (tcount+1 < 35) tcount++; else tcount = 34; 
							break;
				case KEY_BACKSPACE: title[tcount] = ' '; if (tcount-1 >= 0) tcount--; else tcount = 0; break;
				default:
						if(isprint(ch)) title[tcount] = ch & 0xFF;
						if (tcount+1 < 35) tcount++; else tcount = 34;
						break;
			}
			for(count = 0; count < 35; count++) 
				mvwaddch(stdscr, 0, 8 + count, title[count]);
			move(0, tcount + 8);
			refresh();
		}
		for(count = 0; count < 35; count++) 
			tet_opts.sauce_title[count] = title[count];
		save_sauce(&saucy, filename);
		for(count = 0; count < 35; count++) 
			tet_opts.sauce_title[count] = backup[count];
	}
	free(filename);
	return;
}

int save_sauce(SAUCE *saucy, const char *filename) {
	FILE *fd = (FILE *)NULL;
	time_t curtime;
	struct tm *timepntr;

	int count;

	curtime = time(NULL);
	timepntr = localtime(&curtime);

	if (!(fd = fopen(filename, "a"))) {
		return -1;
	}

	saucy->id[0] = 'S';
	saucy->id[1] = 'A';
	saucy->id[2] = 'U';
	saucy->id[3] = 'C';
	saucy->id[4] = 'E';
	saucy->version[0] = '0';
	saucy->version[1] = '0';
	saucy->datatype = 1;

	/* i guess this is y2k compliant ;)) */
	if (timepntr->tm_year >= 100) {
		saucy->date[0] = '2';
		saucy->date[1] = '0';
		saucy->date[2] = (timepntr->tm_year / 10) + '0';
		saucy->date[3] = (timepntr->tm_year % 10) + '0';
	} else {
		saucy->date[0] = '1';
		saucy->date[1] = '9';
		saucy->date[2] = (timepntr->tm_year / 10) + '0';
		saucy->date[3] = (timepntr->tm_year % 10) + '0';
	}

	saucy->date[4] = ((timepntr->tm_mon + 1) / 10) + '0';
	saucy->date[5] = ((timepntr->tm_mon + 1) % 10) + '0';

	saucy->date[6] = (timepntr->tm_mday / 10) + '0';
	saucy->date[7] = (timepntr->tm_mday % 10) + '0';

	for(count = 0; count < 35; count++) 
		saucy->title[count] = tet_opts.sauce_title[count];
	for(count = 0; count < 20; count++)
		saucy->author[count] = tet_opts.sauce_author[count];
	for(count = 0; count < 20; count++)
		saucy->group[count] = tet_opts.sauce_group[count];

	fputc(26, fd);
	fwrite(saucy, sizeof(SAUCE), 1, fd);
	fclose(fd);
	return 0;
}

int save_c(page *curpage, const char *filename) {
	FILE *fd = (FILE *)NULL;
	int y = 0;
	int countx = 0;

	fd = fopen(filename, "w");
	if (fd == NULL) return -1;

	fprintf(fd, "int ansi[%d][%d] = {\n", curpage->hy+1, 80);
	while (y<curpage->ly) {
		fprintf(fd, "{ ");
		for(countx = 0; countx < 79;countx++) 
				fprintf(fd, "%ld,", curpage->buff[y][countx]);
		fprintf(fd, "%ld", curpage->buff[y][countx]);
		fprintf(fd, "},\n");
		y++;
	}
	fprintf(fd, "};\n");
	fclose(fd);
	return 0;
}

int save_ascii(page *curpage, const char *filename) {
	FILE *fd = (FILE *)NULL;
	int y = 0;
	int countx = 0;
	fd = fopen(filename, "w");
	if (fd == NULL) return -1;

	while(y<curpage->ly) {
		for(countx = 0; countx < 79; countx++)
			fprintf(fd, "%c", (char)curpage->buff[y][countx] & 0xFF);
		fprintf(fd, "\n");
		y++;
	}
	fprintf(fd, "\n");
	fclose(fd);
	return 0;
}

int save_ansi(page *curpage, const char *filename) {
	FILE *fd = (FILE *)NULL;
	int lfg, lbg, lbold, lflash;
	int fg, bg, bold, flash;
	int x, y;
	int first;
	int ch;
	int pair;

	pair = ch = x = y = first = 0;
	fd = (FILE *)NULL;

	lfg = fg = 30;
	lbg = bg = 40;
	lbold = bold = 0;
	lflash = flash = 0;

	if ((fd = fopen(filename, "w"))==NULL) return -1;

	while (y<curpage->ly) {
		x = 0;
		while (x<80) {
			ch = curpage->buff[y][x] & 0xFF;
			pair = PAIR_NUMBER(curpage->buff[y][x]);
			fg = bg = 0;
			pair_content(pair, (short *)&fg, (short *)&bg);
			if (curpage->buff[y][x] & A_DIM) {
				fg = 0;
				bg = 0;
				bold = 1;
			} else if (curpage->buff[y][x] & A_BOLD) bold = 1; else bold = 0;
			if (curpage->buff[y][x] & A_BLINK) flash = 1; else flash = 0;
			fg += 30;
			bg += 40;

			if(lbold != bold || lfg != fg || lbg != bg || lflash != flash) {
				/* this character has different attributes */
				/* we must write a ansi code here */
				/* then write the character */
				first = 1;

				/* start the escape code */
				fprintf(fd, "\e[");

				/* do we need to write a bold attribute ? */
				if (bold != lbold) {
						fprintf(fd, "%d", bold);
						first = 0;
						if (bold == 0) {
							if (fg != 37 || bg != 40 || flash != 0) {
								if (flash != 0) fprintf(fd, ";5");
								if (fg != 37) fprintf(fd, ";%d", fg);
								if (bg != 40) fprintf(fd, ";%d", bg);
								fprintf(fd, "m");
								goto addchar;
							}
						} else {
							if (fg != lfg || bg != lbg || flash != lflash) {
								if (flash != lflash) { if (flash) fprintf(fd, ";5"); else fprintf(fd, ";0"); } 
								if (fg != lfg) fprintf(fd, ";%d", fg);
								if (bg != lbg) fprintf(fd, ";%d", bg);
								fprintf(fd, "m");
								goto addchar;
							}
						}
				} 

				if (flash != lflash) {
					if (flash) { 
						if (first) fprintf(fd, "5");
						else fprintf(fd, ";5");
					} else {
						if (first) fprintf(fd, "0");
						else fprintf(fd, ";0");
					}
					first = 0;
				}

				if (fg != lfg) {
					if (first) fprintf(fd, "%d", fg);
					else fprintf(fd, ";%d", fg);
					first = 0;
				}

				if (bg != lbg) {
					if (first) fprintf(fd, "%d", bg);
					else fprintf(fd, ";%d", bg);
					first = 0;
				}
				fprintf(fd, "m");
			}
			addchar:
			lfg = fg;
			lbg = bg;
			lbold = bold;
			lflash = flash;
			fprintf(fd, "%c", ch);
			x++;
		}
		y++;
	}		
	fprintf(fd, "\e[0m");
	fclose(fd);
	return 0;
}

/*
int save_ansi(page *curpage, const char *filename) {
	FILE *fd;
	int ch, spacecount, pair, first; //, count;
	int pos = 0, hpos = (curpage->hy) ? (curpage->hy + 1) * 80 : 80;
	int lfg, lbg, lbold;
	int fg = 0, bg = 0, bold = 0;

	fd = fopen(filename, "w");
	if (fd == NULL) return -1;

	ch = spacecount = first = 0;

	lfg = 30;
	lbg = 40;
	lbold = 0;

	while (pos<hpos) {
		ch = curpage->buff[pos / 80][pos % 80] & 0xFF;
		pair = PAIR_NUMBER(curpage->buff[pos / 80][pos % 80]);

		pair_content(pair, (short *)&fg, (short *)&bg);

		if (curpage->buff[pos / 80][pos % 80] & A_BOLD) bold = 1; else bold = 0;

		fg += 30;
		bg += 40;

		if (ch == 32 && fg == 7 && bg == 0 && bold == 0 && lbold == 0 && lfg == 37 && lbg == 40) {
			spacecount++;
			pos++;
			continue;
		} 

		if (spacecount > 4) { 
			fprintf(fd, "\e[%dC", spacecount);
			spacecount = 0;
		} else if (spacecount) {
			for(count = 0; count < spacecount; count++)
				fprintf(fd, " ");
			spacecount = 0;
		}

		if (lbold == bold && lfg == fg && lbg == bg) {
		} else {

			first = 1;

			if (lbg != bg && first) {
				fprintf(fd, "%d", bg);
				first = 0;
			} else if (lbg != bg) fprintf(fd, ";%d", bg);
			fprintf(fd, "m");
		}
	}
	fprintf(fd, "\e[0m\n");
	fclose(fd);
	return 0;
}
*/
