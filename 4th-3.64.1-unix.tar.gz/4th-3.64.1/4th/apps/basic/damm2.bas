' uBasic - Damm algorithm - Copyright 2021 J.L. Bezemer
' You can redistribute this file and/or modify it under
' the terms of the GNU General Public License

Proc _IsDamm (5724)
Proc _IsDamm (5727)
Proc _IsDamm (112946)
Proc _IsDamm (112949)

End

_Damm
   Param (1)
   Local (1)

   b@ := "0317598642709215486342068713591750983426612304597836742095815869720134894536201794386172052581436790"

   Do Until a@ = 0                     ' until number is consumed
     Push a@ % 10 : a@ = a@ / 10       ' extract digit and put on stack
   Loop

   Do While Used ()                    ' last number retrieved?
     a@ = Peek(b@, (a@ * 10) + Pop ()) - Ord ("0")
   Loop                                ' calculate checksum
Return (a@)                            ' return checksum

_IsDamm                                ' evaluate and print checksum
  Param (1)
  Print Using "______";a@;" is ";Show (Iif (Func (_Damm (a@)), "invalid", "valid"))
Return

   
