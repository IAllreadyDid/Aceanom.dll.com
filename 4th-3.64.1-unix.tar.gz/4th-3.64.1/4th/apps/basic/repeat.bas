' My solution to http://www.rosettacode.org/wiki/Repeat#uBasic.2F4tH
' Copyright J.L. Bezemer 2022

Proc _Repeat (_HelloWorld, 5) : End

_Repeat Param (2) : Local (1) : For c@ = 1 To b@ : Proc a@ : Next : Return
_HelloWorld Print "Hello world!" : Return
