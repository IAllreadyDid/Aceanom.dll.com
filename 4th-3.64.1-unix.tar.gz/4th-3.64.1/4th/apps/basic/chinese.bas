' Taken from: http://www.rosettacode.org/wiki/Chinese_zodiac#FreeBASIC
' Converted to uBasic/4tH by J.L. Bezemer 2022

Dim @y(2)                              ' yin or yang
Dim @e(5)                              ' the elements
Dim @a(12)                             ' the animals

Push Dup("yang"), Dup("yin")           ' fill Ying/Yang table
For i = 1 to 0 Step -1 : @y(i) = Pop() : Next i
                                       ' fill Elements table
Push Dup("Wood"), Dup("Fire"), Dup("Earth"), Dup("Metal"), Dup("Water")
For i = 4 to 0 Step -1 : @e(i) = Pop() : Next i
                                       ' fill Animals table
Push Dup("Rat"),   Dup("Ox"),    Dup("Tiger"), Dup("Rabbit"), Dup("Dragon")
Push Dup("Snake"), Dup("Horse"), Dup("Goat"),  Dup("Monkey"), Dup("Rooster")
Push Dup("Dog"),   Dup("Pig")

For i = 11 to 0 Step -1 : @a(i) = Pop() : Next i
                                       ' now push all the test yeats
Push 76543, 2186, 2020, 1984, 1861, 1801
                                       ' and process them all
Do While Used()                        ' until the stack is empty
  Print Show(FUNC(_Chinese(Pop())))    ' call function
Loop

End

_Chinese                               ' compose string
  Param (1)
  Local (3)

  b@ = a@ % 2
  c@ = (a@ - 4) % 5
  d@ = (a@ - 4) % 12
Return (Join(Str (a@), " is the year of the ", @e(c@), " ", @a(d@), " (", @y(b@), ")."))

