' My solution to http://www.rosettacode.org/wiki/Yin_and_yang#uBasic.2F4tH
' Copyright J.L. Bezemer 2022

Proc _YinYang (18)
End

_YinYang
  Param (1)
  Local (2)

  For b@ = -a@ To a@
    For c@ = -2*a@ To 2*a@
      Print Chr(FUNC(_Pixel (c@, b@, a@)));
    Next
    Print
  Next
Return

_Circle
  Param (4)
  Local (1)

  e@ = ((a@/2) * (a@/2)) + ((b@-c@) * (b@-c@))
Return ((d@ * d@) + 1  > e@)

_Pixel
  Param (3)

  If FUNC(_Circle (a@, b@, -c@ / 2, c@ / 6)) Then Return (Ord ("#"))
  If FUNC(_Circle (a@, b@, c@ / 2, c@ / 6))  Then Return (Ord ("."))
  If FUNC(_Circle (a@, b@, -c@ / 2, c@ / 2)) Then Return (Ord ("."))
  If FUNC(_Circle (a@, b@, c@ / 2, c@ / 2))  Then Return (Ord ("#"))
  If FUNC(_Circle (a@, b@, 0, c@)) Then Return (Iif (a@ < 0, Ord ("."), Ord ("#")))
Return (Ord (" "))

