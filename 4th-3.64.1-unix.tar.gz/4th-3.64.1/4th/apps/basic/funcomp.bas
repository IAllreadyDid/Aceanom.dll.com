' My solution to http://rosettacode.org/wiki/Function_composition#uBasic.2F4tH
' Copyright J.L. Bezemer 2022

Print FUNC(_Compose (_f, _g, 3))
End

_Compose Param (3) : Return (FUNC(a@(FUNC(b@(c@)))))
_f Param (1) : Return (a@ + 1)
_g Param (1) : Return (a@ * 2)

