' My solution to http://www.rosettacode.org/wiki/Price_fraction#uBasic.2F4tH
' Copyright J.L. Bezemer 2022

For i = 0 To 100 Step 5
  Print Using "+?.##"; i, Using "+?.##"; FUNC(_Normalize (FUNC(_Classify (i))))
Next 

End

_Normalize                             ' normalize the price
  Param (1)                            ' class
  Local (4)                            ' accumulator, increment, switch and iterator
  
  b@ = 0 : c@ = 10 : d@ = 2            ' setup accumulator, increment and switch
  
  For e@ = 0 to a@                     ' from zero to class
    If And(e@ + 1, d@) Then d@ = And(d@ + d@, 15) : c@ = c@ - 2
    b@ = b@ + c@                       ' switch increment if needed
  Next                                 ' accumulate price
Return (Min(b@, 100))                  ' clip top of price in accumulator
                                       ' calculate class
_Classify Param (1) : Return ((a@ - (a@>0)) / 5)
