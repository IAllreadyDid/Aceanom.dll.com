' Taken from http://rosettacode.org
' uBasic/4tH version 2021, Hans Bezemer

Print FUNC(_iSqrt(1234567890))
End

_iSqrt Param (1)
  Let q = 1
  Do Until q > a@
    Let q = q * 4
  Loop

  Let z = a@
  Let r = 0

  Do While q > 1
    Let q = q / 4
    Let t = z - r - q
    Let r = r / 2
    If t > -1 Then
      Let z = t
      Let r = r + q
    Endif
  Loop

Return (r)
