' My solution to http://www.rosettacode.org/wiki/Higher-order_functions#uBasic.2F4tH
' Copyright J.L. Bezemer 2022

' Test passing a function to a function:
Print FUNC(_FNtwo(_FNone, 10, 11))
End
 
' Function to be passed:
_FNone Param (2) : Return ((a@ + b@)^2)

' Function taking a function as an argument:
_FNtwo Param (3) : Return (FUNC(a@ (b@, c@)))

