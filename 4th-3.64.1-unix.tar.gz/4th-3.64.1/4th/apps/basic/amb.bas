' My solution to http://www.rosettacode.org/wiki/Amb#uBasic.2F4tH
' Copyright J.L. Bezemer 2022
                                       ' set up the arrays
Push Dup("the"),    Dup("that"),     Dup("a")     : a = FUNC(_Ambsel (0))
Push Dup("frog"),   Dup("elephant"), Dup("thing") : b = FUNC(_Ambsel (a))
Push Dup("walked"), Dup("treaded"),  Dup("grows") : c = FUNC(_Ambsel (b))
Push Dup("slowly"), Dup("quickly")                : f = FUNC(_Ambsel (c))
                                       ' we'll reuse variable f ;-)
Proc _Ambassert (_Connect)             ' now assert the function required

For w = 1 To @(0)                      ' and evaluate..
  For x = a+1 To a+@(a)
    For y = b+1 To b+@(b)
      For z = c+1 To c+@(c)
        If FUNC(_Amb (@(w), @(x))) * FUNC(_Amb (@(x), @(y))) * FUNC(_Amb (@(y), @(z))) Then
          Print Show(@(w)), Show(@(x)), Show(@(y)), Show(@(z))
        EndIf
      Next
    Next
  Next
Next

End

_Ambsel                                ' array setup
  Param (1)
  Local (1)

  @(a@) = Used ()
  For b@ = a@+1 To a@ + @(a@)
    @(b@) = Pop ()
  Next
Return (b@)

_Amb Param (2) : Return (FUNC(f (a@, b@)))
_Ambassert Param (1) : f = a@ : Return ' set up the function
_Connect Param (2) : Return (Peek (a@, Len(a@)-1) = Peek(b@, 0))

