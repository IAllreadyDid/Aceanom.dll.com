' Yellowstone sequence, 2021 J.L. Bezemer

' For n > 3, gcd(a(n), a(n-1)) = 1 and gcd(a(n), a(n-2)) > 1.
' (This is just a restatement of the definition.)
' This is now known to be a permutation of the natural numbers.
' See the 2015 article by Applegate, Havermann, Selcoe, Shevelev, Sloane,
' and Zumkeller.

Dim @y(30)

@y(0) = 1
@y(1) = 2
@y(2) = 3

For i = 3 To 29
  k = 3
  Do
    k = k + 1
    If (FUNC(_gcd(k, @y(i-2))) = 1) + (FUNC(_gcd(k, @y(i-1))) > 1) Then
      Continue
    EndIf

    For j = 0 To i - 1
      If @y(j) = k Then Unloop : Continue
    Next

    @y(i) = k : Break
  Loop
Next

For i = 0 To 29
  Print @y(i); " ";
Next

Print : End

_gcd Param (2)
  If b@ = 0 Then Return (a@)
Return (FUNC(_gcd(b@, a@ % b@)))

