' My solution to http://www.rosettacode.org/wiki/Monads/List_monad#uBasic.2F4tH
' Copyright J.L. Bezemer 2022

' Demonstrate in your programming language the following:
' - Construct a List Monad by writing the "bind" function and the "pure"
'   (sometimes known as "return") function for that Monad (or just use
'   what the language already has implemented);
' - Make two functions, each which take a number and return a monadic number,
'   e.g. Int -> List Int and Int -> List String;
' - Compose the two functions with bind.

s := "[" : Push 5, 4, 3

Do While Used ()
  y = Set (x, Pop ()) + 1
  s = Join (s, Str (Set (z, y * 2)), ", " )
Loop

Print Show (Set (s, Join (Clip (s, 2), "]")))

