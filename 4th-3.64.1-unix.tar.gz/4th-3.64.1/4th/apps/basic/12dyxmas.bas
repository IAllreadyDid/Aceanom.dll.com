' Taken from http://rosettacode.org 
' uBasic/4tH version 2021, Hans Bezemer

Dim @n(12) : Dim @v(12)                ' define both arrays

Proc _DataDays                         ' put data on the stack

For i=11 To 0 Step -1                  ' read them in
  @n(i) = Pop()
Next

Proc _DataGifts                        ' put data on the stack

For i=11 To 0 Step -1                  ' read them in
  @v(i) = Pop()
Next

For i=0 To 11                          ' print all twelve verses
  Print "On the ";Show(@n(i));" day of Christmas"
  Print "My true love gave to me:"

  For j=i To 0 Step -1                 ' show list of gifts
    Print Show(@v(j))
  Next

  Print                                ' next verse
Next
End


_DataDays
  Push Dup("first"), Dup("second"), Dup("third"), Dup ("fourth")
  Push Dup("fifth"), Dup("sixth"), Dup("seventh"), Dup("eighth")
  Push Dup("ninth"), Dup("tenth"), Dup("eleventh"), Dup("twelfth")
Return

_DataGifts
  Push Dup("A partridge in a pear tree.")
  Push Dup("Two turtle doves and")
  Push Dup("Three french hens")
  Push Dup("Four calling birds")
  Push Dup("Five golden rings")
  Push Dup("Six geese a-laying")
  Push Dup("Seven swans a-swimming")
  Push Dup("Eight maids a-milking")
  Push Dup("Nine ladies dancing")
  Push Dup("Ten lords a-leaping")
  Push Dup("Eleven pipers piping")
  Push Dup("Twelve drummers drumming")
Return

