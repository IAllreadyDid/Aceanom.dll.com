1 PRINT TAB(32);"3D PLOT"
2 PRINT TAB(15);"CREATIVE COMPUTING  MORRISTOWN, NEW JERSEY"
3 IF INFO("wordsize") < 64 THEN PRINT "This program requires a 64-bit uBasic" : END
5 PRINT:PRINT:PRINT
100 PRINT
110 FOR X=FUNC(_Itof(-300000)) TO FUNC(_Itof(300000)) STEP FUNC(_Itof(15000))
120 L=0
130 K=(FUNC(_Ftoi(FUNC(_Fdiv(FUNC(_Fsqrt(FUNC(_Itof(9000000))-FUNC(_Fmul(X, X)))), FUNC(_Itof(50000))))))/10000)*5
140 FOR Y=K TO -K STEP -5
150 Z=FUNC(_Ftoi(FUNC(_Itof(250000))+FUNC(_FNa(FUNC(_Fsqrt(FUNC(_Fmul(X, X))+FUNC(_Itof((Y*Y*10000)))))))-FUNC(_Fdiv((7*Y), 10))))/10000
160 IF Z>L THEN L=Z : PRINT TAB(Z);"*";
190 NEXT Y
200 PRINT
210 NEXT X
300 END

_FNa Param (1)
Return (FUNC(_Fmul(FUNC(_Itof(300000)), FUNC(_Fexp(FUNC(_Fdiv(FUNC(_Fmul(-a@, a@)), FUNC(_Itof(1000000)))))))))

_Fmul Param (2) : Return ((a@*b@)/16384)
_Fdiv Param (2) : Return ((a@*16384)/b@)
_Ftoi Param (1) : Return ((10000*a@)/16384)
_Itof Param (1) : Return ((16384*a@)/10000)
_Fprint Param (1) : a@ = FUNC(_Ftoi(a@)) : Print Using "+?.####";a@; : Return
_Fint Param (1) : Return (FUNC(_Itof((FUNC(_Ftoi(a@))/10000)*10000)))
_Fsqrt Param (1) : Return (FUNC(_Itof(FUNC(_Sqrt(FUNC(_Ftoi(a@))*10000)))))

_Fexp
  Param (1)
  Local (1)

  b@ = FUNC(_Exp (abs(a@) * 4))
  If a@<0 Then Return (1073741824/b@)
Return (b@/4)

_Exp
  Param (1)
  Local (2)

  c@=65536
  b@=a@-363409 : If b@>-1 Then a@=b@ : c@=SHL(c@, 8)
  b@=a@-181704 : If b@>-1 Then a@=b@ : c@=SHL(c@, 4)
  b@=a@-90852  : If b@>-1 Then a@=b@ : c@=SHL(c@, 2)
  b@=a@-45426  : If b@>-1 Then a@=b@ : c@=SHL(c@, 1)
  b@=a@-26573  : If b@>-1 Then a@=b@ : c@=c@+SHL(c@, -1)
  b@=a@-14624  : If b@>-1 Then a@=b@ : c@=c@+SHL(c@, -2)
  b@=a@-7719   : If b@>-1 Then a@=b@ : c@=c@+SHL(c@, -3)
  b@=a@-3973   : If b@>-1 Then a@=b@ : c@=c@+SHL(c@, -4)
  b@=a@-2017   : If b@>-1 Then a@=b@ : c@=c@+SHL(c@, -5)
  b@=a@-1016   : If b@>-1 Then a@=b@ : c@=c@+SHL(c@, -6)
  b@=a@-510    : If b@>-1 Then a@=b@ : c@=c@+SHL(c@, -7)
  If (AND(a@, 256)) Then c@=c@+SHL(c@, -8)
  If (AND(a@, 128)) Then c@=c@+SHL(c@, -9)
  If (AND(a@, 64))  Then c@=c@+SHL(c@, -10)
  If (AND(a@, 32))  Then c@=c@+SHL(c@, -11)
  If (AND(a@, 16))  Then c@=c@+SHL(c@, -12)
  If (AND(a@, 8))   Then c@=c@+SHL(c@, -13)
  If (AND(a@, 4))   Then c@=c@+SHL(c@, -14)
  If (AND(a@, 2))   Then c@=c@+SHL(c@, -15)
  If (AND(a@, 1))   Then c@=c@+SHL(c@, -16)
Return (c@)

_Sqrt
  Param (1)
  Local (3)

  Let b@ = 1
  Let c@ = 0

  Do Until b@ > a@
    Let b@ = b@ * 4
  Loop

  Do While b@ > 1
    Let b@ = b@ / 4
    Let d@ = a@ - c@ - b@
    Let c@ = c@ / 2
    If d@ > -1 Then
      Let a@ = d@
      Let c@ = c@ + b@
    Endif
  Loop

Return (c@)
