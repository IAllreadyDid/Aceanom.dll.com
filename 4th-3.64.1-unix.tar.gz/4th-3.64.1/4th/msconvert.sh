mkdir dos
mkdir dos/examples

for file in `ls *.4th`
  do duc -d $file dos/examples/$file
done

cp *.scr dos/examples
duc -d Makefile dos/examples/Makefile

mkdir dos/4pp
mkdir dos/4pp/lib
mkdir dos/4pp/foos

cd 4pp
for file in `ls *.4pp`
  do duc -d $file ../dos/4pp/$file
done

cd lib
for file in `ls *.4pp`
  do duc -d $file ../../dos/4pp/lib/$file
done

cd ../foos
for file in `ls *.4pp`
  do duc -d $file ../../dos/4pp/lib/$file
done

cd ../..

mkdir dos/apps
mkdir dos/apps/basic
mkdir dos/apps/bf
mkdir dos/apps/data
mkdir dos/apps/graphics
mkdir dos/apps/lisp
mkdir dos/apps/markov
mkdir dos/apps/simpladv
mkdir dos/apps/tinyc
mkdir dos/apps/topitsm
mkdir dos/apps/uyjhmnn
mkdir dos/apps/wirewrld

cd apps/basic
for file in `ls *.bas`
  do duc -d $file ../../dos/apps/basic/$file
done

cd ../bf
for file in `ls *.b`
  do duc -d $file ../../dos/apps/bf/$file
done

cd ../data
cp * ../../dos/apps/data

cd ../graphics
for file in `ls *.txt`
  do duc -d $file ../../dos/apps/graphics/$file
done

cp *.ppm ../../dos/apps/graphics

cd ../lisp
for file in `ls *.scm`
  do duc -d $file ../../dos/apps/wirewrld/$file
done

cd ../markov
for file in `ls *.mrk`
  do duc -d $file ../../dos/apps/markov/$file
done

cd ../simpladv
for file in `ls *.txt *.chs`
  do duc -d $file ../../dos/apps/simpladv/$file
done

cd ../tinyc
for file in `ls *.tc`
  do duc -d $file ../../dos/apps/tinyc/$file
done

cd ../topitsm
for file in `ls *.csv *.ini`
  do duc -d $file ../../dos/apps/topitsm/$file
done

cp *.dbm ../../dos/apps/topitsm
cp *.idx ../../dos/apps/topitsm

cd ../uyjhmnn
for file in `ls *.uyj`
  do duc -d $file ../../dos/apps/uyjhmnn/$file
done

cd ../wirewrld
for file in `ls *.ww`
  do duc -d $file ../../dos/apps/wirewrld/$file
done

cd ../..
mkdir dos/bench

cd bench
for file in `ls *.4th`
  do duc -d $file ../dos/bench/$file
done

cd ..
mkdir dos/demo

cd demo
for file in `ls *.4th`
  do duc -d $file ../dos/demo/$file
done

cd ..
mkdir dos/lib

cd lib
for file in `ls *.4th`
  do duc -d $file ../dos/lib/$file
done

cd ..
